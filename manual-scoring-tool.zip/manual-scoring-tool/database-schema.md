# Database Schema - Manual Scoring Tool

## Overview

This document defines the database schema for storing manual scores (ground truth data) created by expert coaches.

## ManualScores Collection

### Collection Name
`manualscores`

### Purpose
Store expert coach scores for drill videos to be used as ground truth training data for AI model improvement.

### Schema Definition

```typescript
interface IManualScore {
  _id: ObjectId;                    // MongoDB unique identifier
  videoUploadsId: string;           // Reference to videoUploads._id
  coachId: string;                  // Reference to appUser._id
  coachName: string;                // Coach display name (denormalized for reporting)
  gameType: UPLOAD_VIDEO_GAME_TYPE; // Enum: drill type (e.g., PASSING_RECEIVING_TURNING)

  granularity: 'overall' | 'category' | 'metric' | 'activity';

  scores: {
    // Granularity-specific score structure
    overall?: number;               // Used when granularity = 'overall'

    categories?: {                  // Used when granularity = 'category'
      [categoryName: string]: number;
      // Example:
      // "Dribbling": 85,
      // "Passing": 90,
      // "First Touch": 78
    };

    metrics?: {                     // Used when granularity = 'metric'
      [categoryName: string]: {
        [metricName: string]: {
          value?: number | string;  // Raw measured value (e.g., 12.5 seconds, "15 touches")
          score: number;            // Subjective score 0-100
        };
      };
      // Example:
      // "Dribbling": {
      //   "Ball Distance from Foot": { value: 0.35, score: 88 },  // 0.35 meters
      //   "No. of Touches": { value: 15, score: 92 },             // 15 touches
      //   "Speed to Complete": { value: 12.5, score: 85 }         // 12.5 seconds
      // }
    };

    activities?: Array<{            // Used when granularity = 'activity'
      activityIndex: number;        // Position in activity timeline
      type: 'Passing' | 'Dribbling';
      score: number;                // 0-100 score for this activity
      frames: {
        start: number;              // Start frame number
        end: number;                // End frame number
      };
    }>;
  };

  notes: string;                    // Coach's qualitative observations
  scoringDuration: number;          // Time spent scoring in seconds
  createdAt: Date;                  // Timestamp when score created
  updatedAt: Date;                  // Timestamp when last updated
  status: 'draft' | 'submitted';    // Draft allows saving work in progress

  // Quality tracking fields
  confidenceLevel?: number;         // Coach's confidence (1-5 scale)
  difficultyRating?: number;        // Video difficulty to score (1-5 scale)
}
```

### Indexes

```javascript
// Compound unique index - prevent duplicate scores from same coach
manualScoresSchema.index({ videoUploadsId: 1, coachId: 1 }, { unique: true });

// Single field indexes for common queries
manualScoresSchema.index({ videoUploadsId: 1 });  // Get all scores for a video
manualScoresSchema.index({ coachId: 1 });         // Get all scores by a coach
manualScoresSchema.index({ gameType: 1 });        // Filter by drill type
manualScoresSchema.index({ status: 1 });          // Filter drafts vs submitted
manualScoresSchema.index({ createdAt: -1 });      // Sort by most recent
```

### Field Descriptions

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `videoUploadsId` | String | Yes | Links to video in videoUploads collection |
| `coachId` | String | Yes | User ID of coach who scored the video |
| `coachName` | String | Yes | Display name for reporting (denormalized) |
| `gameType` | Enum | Yes | Drill type from UPLOAD_VIDEO_GAME_TYPE enum |
| `granularity` | Enum | Yes | Scoring detail level |
| `scores` | Object | Yes | Score data structure (varies by granularity) |
| `notes` | String | No | Coach's comments and observations |
| `scoringDuration` | Number | Yes | Time in seconds spent scoring |
| `createdAt` | Date | Yes | Creation timestamp |
| `updatedAt` | Date | Yes | Last update timestamp |
| `status` | Enum | Yes | 'draft' or 'submitted' |
| `confidenceLevel` | Number | No | 1-5 rating of coach's confidence |
| `difficultyRating` | Number | No | 1-5 rating of video difficulty |

### Validation Rules

```javascript
// Score values must be 0-100
scores.overall: { min: 0, max: 100 }
scores.categories[*]: { min: 0, max: 100 }
scores.metrics[*][*]: { min: 0, max: 100 }
scores.activities[*].score: { min: 0, max: 100 }

// Confidence and difficulty are 1-5
confidenceLevel: { min: 1, max: 5 }
difficultyRating: { min: 1, max: 5 }

// Status can only be 'draft' or 'submitted'
status: { enum: ['draft', 'submitted'] }

// Granularity validation
granularity: { enum: ['overall', 'category', 'metric', 'activity'] }
```

## Score Structure Examples

### Example 1: Overall Granularity

```json
{
  "_id": "507f1f77bcf86cd799439011",
  "videoUploadsId": "60d5ec49f1b2c8b1f8c4e123",
  "coachId": "60a3d1e9f8b4c9a1234b5678",
  "coachName": "John Smith",
  "gameType": "TRIPLE_CONE_DRILL",
  "granularity": "overall",
  "scores": {
    "overall": 87
  },
  "notes": "Good speed and ball control. Minor issue with final turn.",
  "scoringDuration": 180,
  "createdAt": "2024-12-02T10:30:00Z",
  "updatedAt": "2024-12-02T10:33:00Z",
  "status": "submitted",
  "confidenceLevel": 4,
  "difficultyRating": 2
}
```

### Example 2: Category Granularity

```json
{
  "_id": "507f1f77bcf86cd799439012",
  "videoUploadsId": "60d5ec49f1b2c8b1f8c4e124",
  "coachId": "60a3d1e9f8b4c9a1234b5678",
  "coachName": "John Smith",
  "gameType": "PASSING_RECEIVING_TURNING",
  "granularity": "category",
  "scores": {
    "categories": {
      "Dribbling": 85,
      "Passing": 92,
      "First Touch": 78
    }
  },
  "notes": "Excellent passing accuracy. First touch needs improvement.",
  "scoringDuration": 240,
  "createdAt": "2024-12-02T11:00:00Z",
  "updatedAt": "2024-12-02T11:04:00Z",
  "status": "submitted",
  "confidenceLevel": 5,
  "difficultyRating": 3
}
```

### Example 3: Metric Granularity

```json
{
  "_id": "507f1f77bcf86cd799439013",
  "videoUploadsId": "60d5ec49f1b2c8b1f8c4e125",
  "coachId": "60a3d1e9f8b4c9a1234b5679",
  "coachName": "Sarah Jones",
  "gameType": "DRIBBLE_PASS_DRIBBLE",
  "granularity": "metric",
  "scores": {
    "metrics": {
      "Dribbling": {
        "Ball Distance from Foot": {
          "value": 0.35,
          "score": 88
        },
        "No. of Touches": {
          "value": 15,
          "score": 92
        },
        "Speed to Complete": {
          "value": 12.5,
          "score": 85
        }
      },
      "Passing": {
        "Angle of Ball Return": {
          "value": 45,
          "score": 90
        },
        "Passing Duration": {
          "value": 2.3,
          "score": 87
        }
      }
    }
  },
  "notes": "Strong technical execution across all metrics. Speed: 12.5s, Ball control excellent at 0.35m average.",
  "scoringDuration": 360,
  "createdAt": "2024-12-02T12:00:00Z",
  "updatedAt": "2024-12-02T12:06:00Z",
  "status": "submitted",
  "confidenceLevel": 5,
  "difficultyRating": 4
}
```

### Example 4: Activity Granularity

```json
{
  "_id": "507f1f77bcf86cd799439014",
  "videoUploadsId": "60d5ec49f1b2c8b1f8c4e126",
  "coachId": "60a3d1e9f8b4c9a1234b5679",
  "coachName": "Sarah Jones",
  "gameType": "PASSING_RECEIVING_TURNING",
  "granularity": "activity",
  "scores": {
    "activities": [
      {
        "activityIndex": 0,
        "type": "Dribbling",
        "score": 85,
        "frames": { "start": 0, "end": 120 }
      },
      {
        "activityIndex": 1,
        "type": "Passing",
        "score": 92,
        "frames": { "start": 121, "end": 180 }
      },
      {
        "activityIndex": 2,
        "type": "Dribbling",
        "score": 88,
        "frames": { "start": 181, "end": 300 }
      }
    ]
  },
  "notes": "Consistent performance throughout all activities.",
  "scoringDuration": 420,
  "createdAt": "2024-12-02T13:00:00Z",
  "updatedAt": "2024-12-02T13:07:00Z",
  "status": "submitted",
  "confidenceLevel": 4,
  "difficultyRating": 5
}
```

### Example 5: Draft Status

```json
{
  "_id": "507f1f77bcf86cd799439015",
  "videoUploadsId": "60d5ec49f1b2c8b1f8c4e127",
  "coachId": "60a3d1e9f8b4c9a1234b5678",
  "coachName": "John Smith",
  "gameType": "ZIGZAG_DRILL",
  "granularity": "category",
  "scores": {
    "categories": {
      "Dribbling": 80
    }
  },
  "notes": "Work in progress...",
  "scoringDuration": 120,
  "createdAt": "2024-12-02T14:00:00Z",
  "updatedAt": "2024-12-02T14:02:00Z",
  "status": "draft",
  "confidenceLevel": null,
  "difficultyRating": null
}
```

## Relationships

### Related Collections

```
manualscores
├── videoUploadsId → videoUploads._id
│   └── Contains: videoUrl, gameType, drillLevel, status, userId (player)
│
├── coachId → appUsers._id
│   └── Contains: name, email, roles, clubMemberships
│
└── gameType (comparison) → drillScores.gameType
    └── For AI vs manual score comparison
```

### Query Patterns

#### Get all scores for a video
```javascript
db.manualscores.find({ videoUploadsId: "60d5ec49f1b2c8b1f8c4e123" })
```

#### Get all scores by a coach
```javascript
db.manualscores.find({ coachId: "60a3d1e9f8b4c9a1234b5678" })
```

#### Get submitted scores for a drill type
```javascript
db.manualscores.find({
  gameType: "PASSING_RECEIVING_TURNING",
  status: "submitted"
})
```

#### Get videos with multiple manual scores (inter-rater reliability)
```javascript
db.manualscores.aggregate([
  { $match: { status: "submitted" } },
  { $group: {
    _id: "$videoUploadsId",
    count: { $sum: 1 },
    scores: { $push: "$scores" },
    coaches: { $push: "$coachName" }
  }},
  { $match: { count: { $gte: 2 } } }
])
```

#### Get coach statistics
```javascript
db.manualscores.aggregate([
  { $match: { status: "submitted" } },
  { $group: {
    _id: "$coachId",
    coachName: { $first: "$coachName" },
    totalScored: { $sum: 1 },
    avgDuration: { $avg: "$scoringDuration" },
    avgConfidence: { $avg: "$confidenceLevel" }
  }}
])
```

## Data Integrity

### Constraints

1. **Unique Coach-Video Pair**: Each coach can score a video only once
   ```javascript
   { videoUploadsId: 1, coachId: 1 } // unique compound index
   ```

2. **Valid References**:
   - `videoUploadsId` must exist in `videoUploads` collection
   - `coachId` must exist in `appUsers` collection with PLATFORM_ADMIN role

3. **Score Validity**:
   - All scores must be between 0-100
   - Granularity must match score structure
   - Required fields must be present based on granularity

### Data Migration

If schema changes are needed:

```javascript
// Example: Add new field with default value
db.manualscores.updateMany(
  { version: { $exists: false } },
  { $set: { version: 1, migratedAt: new Date() } }
)
```

## Performance Considerations

### Index Usage

```javascript
// Most common queries and their indexes
// Query: Get scores for video
// Uses: videoUploadsId_1

// Query: Get scores by coach
// Uses: coachId_1

// Query: Filter by drill type and status
// Uses: gameType_1 + status_1 (compound may be beneficial)

// Query: Sort by recent
// Uses: createdAt_-1
```

### Estimated Document Size

- **Overall**: ~300-500 bytes
- **Category**: ~400-600 bytes
- **Metric**: ~600-1000 bytes
- **Activity**: ~800-2000 bytes (depends on activity count)

### Storage Estimates

- 1,000 scores: ~0.5-1 MB
- 10,000 scores: ~5-10 MB
- 100,000 scores: ~50-100 MB

## Backup & Retention

### Backup Strategy
- Daily automated backups of entire collection
- Retain backups for 30 days
- Export critical training datasets separately

### Retention Policy
- Draft scores: Delete after 30 days of inactivity
- Submitted scores: Retain indefinitely (training data)
- Audit trail: Keep createdAt/updatedAt for compliance

---

**Document Version**: 1.0
**Last Updated**: 2024-12-02
**Schema Version**: 1.0
