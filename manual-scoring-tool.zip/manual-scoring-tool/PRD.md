# Manual Scoring Tool - Product Requirements Document

## Executive Summary

Create a manual scoring interface for expert football coaches to score drill videos, generating high-quality ground truth data for supervised learning to improve the AI scoring model accuracy.

## Problem Statement

Currently, the AI scoring model has no systematic way to collect expert-scored ground truth data for:
- Model training and improvement
- Validation of AI scoring accuracy
- Identification of scoring edge cases and failure modes
- Continuous model refinement

## Goals

### Primary Goals
1. Enable expert coaches to manually score drill videos with configurable granularity
2. Create a reliable dataset of ground truth scores for ML model training
3. Provide comparison tools to analyze AI vs human scoring differences
4. Track scoring quality metrics including inter-rater reliability

### Secondary Goals
1. Streamline the scoring workflow to minimize time per video
2. Export data in formats compatible with ML training pipelines
3. Build a foundation for continuous model improvement cycles

## User Personas

### Platform Administrator / ML Engineer
- **Need**: High-quality labeled training data
- **Usage**: Assigns scoring tasks, exports datasets, monitors quality
- **Pain Points**: Inconsistent labeling, poor inter-rater agreement
- **Success Metric**: >80% inter-rater agreement on scored videos

### Expert Football Coach (Scorer)
- **Need**: Intuitive scoring interface with video playback controls
- **Usage**: Reviews drill videos and assigns scores based on expertise
- **Pain Points**: Complex interfaces, unclear scoring criteria, slow video loading
- **Success Metric**: Can score 15+ videos per hour

## Requirements

### Functional Requirements

#### FR1: Video Selection & Browsing
- **FR1.1**: Display list of processable drill videos with metadata (player, drill type, date)
- **FR1.2**: Filter videos by drill type, level, date range
- **FR1.3**: Search videos by player name or drill type
- **FR1.4**: Show scoring status (unscored, partially scored, scored)
- **FR1.5**: Support pagination for large video datasets (25-100 per page)

#### FR2: Scoring Interface
- **FR2.1**: Video player with standard controls (play, pause, seek, speed control)
- **FR2.2**: Frame-by-frame navigation capability
- **FR2.3**: Configurable scoring granularity:
  - **Overall**: Single 0-100 score for entire drill
  - **Category**: Separate scores for Dribbling, Passing, First Touch (where applicable)
  - **Metric**: Individual scores for each metric (Ball Distance, Touches, Speed, etc.)
  - **Activity**: Score each activity/segment within video separately
- **FR2.4**: Numeric input fields with 0-100 validation
- **FR2.5**: Notes/comments field for qualitative observations
- **FR2.6**: Confidence rating (1-5) for scorer's certainty
- **FR2.7**: Difficulty rating (1-5) for video complexity
- **FR2.8**: Draft save functionality (save work in progress)
- **FR2.9**: Submit final score

#### FR3: Comparison & Analytics
- **FR3.1**: Side-by-side comparison of manual score vs AI score
- **FR3.2**: Highlight differences with color coding (green = close, red = large difference)
- **FR3.3**: Display AI score breakdown (categories, metrics, activities)
- **FR3.4**: Show multiple manual scores when same video scored by different coaches

#### FR4: Quality Metrics Dashboard
- **FR4.1**: Inter-rater reliability metrics (videos with multiple scores)
- **FR4.2**: Per-coach statistics (total scored, average time, consistency)
- **FR4.3**: Scoring distribution visualizations
- **FR4.4**: Identify outlier scores for review

#### FR5: Data Export
- **FR5.1**: Export to CSV format with columns:
  - videoId, videoUrl, gameType, coachId, coachName, granularity
  - manualScore (overall), aiScore, difference
  - timestamp, scoringDuration, confidenceLevel, notes
- **FR5.2**: Export to JSON format with full nested score structure
- **FR5.3**: Filter exports by drill type, date range, coach
- **FR5.4**: Download generated file to local machine

#### FR6: Access Control
- **FR6.1**: Restrict all functionality to PLATFORM_ADMIN role only
- **FR6.2**: Display clear error message for unauthorized access attempts
- **FR6.3**: Navigation link visible only to PLATFORM_ADMIN users

### Non-Functional Requirements

#### NFR1: Performance
- Video player loads within 2 seconds
- Dashboard loads 50 videos within 3 seconds
- Export of 1000 records completes within 10 seconds
- No UI lag during score input

#### NFR2: Usability
- Scoring interface intuitive enough for new coaches to use without training
- Clear visual feedback for validation errors
- Keyboard shortcuts for common actions (play/pause, frame navigation)
- Mobile-responsive (tablet support at minimum)

#### NFR3: Reliability
- Draft auto-save every 30 seconds to prevent data loss
- Graceful handling of video loading failures
- Data validation on both client and server
- Transaction rollback on save failures

#### NFR4: Scalability
- Support 10,000+ videos in database
- Handle 10+ concurrent scoring sessions
- Efficient pagination and lazy loading
- Database indexes for fast queries

#### NFR5: Maintainability
- Follow existing codebase patterns and conventions
- Comprehensive API documentation
- Unit test coverage >70%
- Clear error messages and logging

## User Stories

### US1: Score a Drill Video
**As a** platform administrator
**I want to** select a drill video and assign scores
**So that** I can create ground truth data for model training

**Acceptance Criteria**:
- Can browse available videos with filters
- Can select granularity before scoring
- Can input scores with validation
- Can save draft and submit final score
- Receives confirmation on successful submission

### US2: Compare Manual vs AI Scores
**As a** platform administrator
**I want to** compare my manual score with the AI's score
**So that** I can identify where the AI model needs improvement

**Acceptance Criteria**:
- Can view side-by-side comparison
- Can see score differences highlighted
- Can see detailed breakdowns for both scores
- Can access comparison from scoring interface

### US3: Export Training Dataset
**As an** ML engineer
**I want to** export all manual scores with AI scores
**So that** I can train an improved scoring model

**Acceptance Criteria**:
- Can export to CSV or JSON
- Can filter by drill type and date range
- Export includes all required fields
- File downloads successfully

### US4: Monitor Scoring Quality
**As a** platform administrator
**I want to** view quality metrics for manual scoring
**So that** I can ensure data quality and consistency

**Acceptance Criteria**:
- Can see inter-rater reliability for multi-scored videos
- Can see per-coach statistics
- Can identify outliers or inconsistent scores
- Metrics update in real-time as new scores added

### US5: Score at Different Granularities
**As a** platform administrator
**I want to** choose scoring granularity based on drill complexity
**So that** I can balance detail level with scoring speed

**Acceptance Criteria**:
- Can select granularity before scoring
- Form dynamically updates based on selection
- All granularities validate correctly
- Can change granularity and form resets

## Out of Scope (Future Enhancements)

- Video annotation/markup tools (frame marking, drawing)
- Automated score suggestions based on AI confidence
- Real-time collaborative scoring (multiple coaches simultaneously)
- Mobile app version (web-only for v1)
- Automated ML retraining pipeline integration
- Batch scoring workflow (score multiple videos in sequence)
- Video clip extraction for specific activities
- Advanced analytics (drift detection, bias analysis)

## Success Metrics

### Adoption Metrics
- 3+ expert coaches actively scoring within first month
- 100+ videos scored within first 2 months
- Average 10+ scores per coach per week

### Quality Metrics
- Inter-rater agreement (Cronbach's alpha) >0.80 for videos scored by 2+ coaches
- Average confidence rating >3.5/5
- <10% scores requiring revision/correction

### Efficiency Metrics
- Average scoring time <5 minutes per video (category granularity)
- <5% draft scores abandoned without submission
- Export completion time <10 seconds for 1000 records

### Impact Metrics
- AI model accuracy improves by 5-10% after retraining with manual scores
- Reduction in user complaints about AI scoring accuracy
- Clear identification of model failure modes (specific drill types, edge cases)

## Dependencies

### Technical Dependencies
- aim-coach-portal-api running and accessible
- aim-coach-portal-ui with PLATFORM_ADMIN authentication
- MongoDB database with VideoUploads and DrillScores collections
- aim-common-plugin updated with ManualScores schema
- Google Cloud Storage for video hosting

### Business Dependencies
- Identification and onboarding of 3-5 expert coaches
- Definition of scoring criteria and guidelines
- Approval for PLATFORM_ADMIN role usage

## Risks & Mitigation

### Risk 1: Low Coach Participation
**Impact**: Insufficient training data
**Likelihood**: Medium
**Mitigation**:
- Keep interface simple and fast
- Provide scoring guidelines and examples
- Offer incentives (compensation, gamification)

### Risk 2: Poor Inter-Rater Reliability
**Impact**: Unreliable training data
**Likelihood**: Medium
**Mitigation**:
- Provide clear scoring rubrics
- Conduct calibration sessions with coaches
- Highlight disagreements for discussion

### Risk 3: Performance Issues with Large Datasets
**Impact**: Slow dashboard, poor UX
**Likelihood**: Low
**Mitigation**:
- Implement pagination and lazy loading
- Add database indexes
- Cache frequently accessed data

### Risk 4: Video Loading Failures
**Impact**: Frustrated users, abandoned scores
**Likelihood**: Low
**Mitigation**:
- Implement retry logic
- Show clear error messages
- Provide fallback to video URL

## Timeline Estimate

### Phase 1: Database & Backend (1 week)
- Create ManualScores schema
- Implement DAO, service, controller
- Create API endpoints
- Unit testing

### Phase 2: Frontend Core (1.5 weeks)
- Scoring dashboard page
- Video selection and filtering
- Scoring interface with video player
- Form validation

### Phase 3: Advanced Features (1 week)
- Comparison view component
- Quality metrics dashboard
- Export functionality (CSV/JSON)

### Phase 4: Testing & QA (1 week)
- Integration testing
- UAT with sample coaches
- Bug fixes and refinements
- Performance optimization

### Phase 5: Deployment (0.5 weeks)
- Deploy to staging
- Production deployment
- Documentation and training

**Total Estimated Timeline**: 5 weeks

## Approval

- [ ] Product Owner: _______________  Date: _______
- [ ] Engineering Lead: _______________  Date: _______
- [ ] UX Designer: _______________  Date: _______
- [ ] QA Lead: _______________  Date: _______

---

**Document Version**: 1.0
**Last Updated**: 2024-12-02
**Author**: Product Team
**Status**: Draft - Awaiting Approval
