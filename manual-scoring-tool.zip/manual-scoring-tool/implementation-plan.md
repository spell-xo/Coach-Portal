# Implementation Plan - Manual Scoring Tool

This document provides a step-by-step guide for implementing the manual scoring tool.

## Overview

The implementation is divided into 5 phases:
1. Database Schema (aim-common-plugin)
2. Backend API (aim-coach-portal-api)
3. Frontend UI (aim-coach-portal-ui)
4. Testing & QA
5. Deployment

**Total Estimated Time**: 5 weeks

---

## Phase 1: Database Schema (3-4 days)

### Step 1.1: Create ManualScores Schema

**File**: `/Users/davidconroy/AIM/aim-common-plugin/src/schemas/manualScoresSchema.ts`

Create new Mongoose schema for manual scores with all fields defined in database-schema.md.

**Key Fields**:
- videoUploadsId, coachId, coachName, gameType
- granularity (enum)
- scores (dynamic object based on granularity)
- notes, scoringDuration, status
- confidenceLevel, difficultyRating
- createdAt, updatedAt

**Indexes**:
```typescript
manualScoresSchema.index({ videoUploadsId: 1, coachId: 1 }, { unique: true });
manualScoresSchema.index({ videoUploadsId: 1 });
manualScoresSchema.index({ coachId: 1 });
manualScoresSchema.index({ gameType: 1 });
manualScoresSchema.index({ status: 1 });
manualScoresSchema.index({ createdAt: -1 });
```

### Step 1.2: Create TypeScript Types

**File**: `/Users/davidconroy/AIM/aim-common-plugin/src/types/manualScores.ts`

Define TypeScript interfaces:
```typescript
export interface IManualScore {
  // ... all fields
}

export interface IManualScoreOverall {
  overall: number;
}

export interface IManualScoreCategory {
  categories: { [key: string]: number };
}

export interface IManualScoreMetric {
  metrics: { [category: string]: { [metric: string]: number } };
}

export interface IManualScoreActivity {
  activities: Array<{
    activityIndex: number;
    type: 'Passing' | 'Dribbling';
    score: number;
    frames: { start: number; end: number };
  }>;
}
```

### Step 1.3: Export Schema

**File**: `/Users/davidconroy/AIM/aim-common-plugin/src/schemas/index.ts`

Add export:
```typescript
export { default as ManualScoresSchema } from './manualScoresSchema.js';
```

**File**: `/Users/davidconroy/AIM/aim-common-plugin/src/types/index.ts`

Add export:
```typescript
export * from './manualScores.js';
```

### Step 1.4: Build and Publish

```bash
cd /Users/davidconroy/AIM/aim-common-plugin
npm run build
# Verify dist/ files are generated correctly
```

### Step 1.5: Update Dependencies

```bash
cd /Users/davidconroy/AIM/aim-coach-portal-api
npm install ../aim-common-plugin

cd /Users/davidconroy/AIM/aim-coach-portal-ui
# No install needed for UI
```

**Deliverable**: ManualScores schema built and linked

---

## Phase 2: Backend API (1.5-2 weeks)

### Step 2.1: Create DAO Layer

**File**: `/Users/davidconroy/AIM/aim-coach-portal-api/src/DAO/manualScoringDAO.js`

Implement database access functions:

```javascript
// Core CRUD operations
export const getManualScores = async (filters = {}) => { /* ... */ };
export const getManualScoreById = async (scoreId) => { /* ... */ };
export const getManualScoresByVideo = async (videoId) => { /* ... */ };
export const createManualScore = async (scoreData) => { /* ... */ };
export const updateManualScore = async (scoreId, updates) => { /* ... */ };

// Complex queries
export const getUnscoredVideos = async (filters) => { /* ... */ };
export const getComparisonData = async (videoId) => { /* ... */ };
export const getQualityMetrics = async () => { /* ... */ };
export const exportScoringData = async (filters = {}) => { /* ... */ };
```

**Key Implementation Details**:
- Use `getModel('manualScoresSchema')` from aim-common-plugin
- Handle MongoDB queries with proper error handling
- Implement aggregation pipelines for quality metrics
- Join with VideoUploads and DrillScores for comparison

**Tests**: Create `tests/unit/manualScoringDAO.test.js`

### Step 2.2: Create Service Layer

**File**: `/Users/davidconroy/AIM/aim-coach-portal-api/src/services/manualScoringService.js`

Implement business logic:

```javascript
export const getUnscoredVideos = async (filters) => { /* ... */ };
export const getManualScoresByVideo = async (videoId) => { /* ... */ };
export const createManualScore = async (scoreData, coachId, coachName) => { /* validation + DAO call */ };
export const updateManualScore = async (scoreId, updates, coachId) => { /* ownership check + update */ };
export const getComparisonData = async (videoId) => { /* ... */ };
export const getQualityMetrics = async () => { /* ... */ };
export const exportScoringData = async (format, filters) => { /* CSV/JSON conversion */ };
```

**Key Features**:
- Validate score data based on granularity
- Check ownership before updates
- Convert to CSV format for exports
- Calculate quality metrics

**Helper Functions**:
```javascript
function validateScoreData(scoreData) { /* validate 0-100 range */ }
function convertToCSV(data) { /* convert JSON to CSV string */ }
function extractOverallScore(scores) { /* extract single score from any granularity */ }
```

**Tests**: Create `tests/unit/manualScoringService.test.js`

### Step 2.3: Create Controller Layer

**File**: `/Users/davidconroy/AIM/aim-coach-portal-api/src/controllers/manualScoringController.js`

Implement HTTP request handlers:

```javascript
export const getUnscoredVideos = async (req, res, next) => { /* ... */ };
export const getManualScoresByVideo = async (req, res, next) => { /* ... */ };
export const createManualScore = async (req, res, next) => { /* ... */ };
export const updateManualScore = async (req, res, next) => { /* ... */ };
export const getComparisonData = async (req, res, next) => { /* ... */ };
export const getQualityMetrics = async (req, res, next) => { /* ... */ };
export const exportScoringData = async (req, res, next) => { /* ... */ };
```

**Response Patterns**:
```javascript
// Success
res.status(200).json({ success: true, data: result });

// Created
res.status(201).json({ success: true, data: newScore });

// Error (handled by middleware)
next(new ApiError(400, 'Validation failed'));
```

### Step 2.4: Create Platform Admin Middleware

**File**: `/Users/davidconroy/AIM/aim-coach-portal-api/src/middleware/platformAdminMiddleware.js`

```javascript
export const requirePlatformAdmin = (req, res, next) => {
  const isPlatformAdmin = req.user.roles?.includes('PLATFORM_ADMIN') ||
                          req.user.primaryRole === 'PLATFORM_ADMIN' ||
                          req.user.context === 'platformAdmin';

  if (!isPlatformAdmin) {
    logger.warn('Non-admin access attempt', { userId: req.user.sub });
    throw new ApiError(403, 'Platform Admin role required');
  }

  next();
};
```

### Step 2.5: Create Routes

**File**: `/Users/davidconroy/AIM/aim-coach-portal-api/src/routes/v1/manualScoring.js`

```javascript
import express from 'express';
import * as controller from '../../controllers/manualScoringController.js';
import authMiddleware from '../../middleware/authMiddleware.js';
import { requirePlatformAdmin } from '../../middleware/platformAdminMiddleware.js';

const router = express.Router();

router.use(authMiddleware);
router.use(requirePlatformAdmin);

router.get('/videos', controller.getUnscoredVideos);
router.get('/video/:videoId', controller.getManualScoresByVideo);
router.post('/', controller.createManualScore);
router.patch('/:scoreId', controller.updateManualScore);
router.get('/comparison/:videoId', controller.getComparisonData);
router.get('/quality-metrics', controller.getQualityMetrics);
router.get('/export', controller.exportScoringData);

export default router;
```

### Step 2.6: Register Routes in App

**File**: `/Users/davidconroy/AIM/aim-coach-portal-api/src/app.js`

Add import:
```javascript
import manualScoringRoutes from './routes/v1/manualScoring.js';
```

Register routes (after other routes):
```javascript
app.use('/api/v1/manual-scoring', manualScoringRoutes);
```

### Step 2.7: Test API Endpoints

Use Postman or curl to test:
- GET /api/v1/manual-scoring/videos
- POST /api/v1/manual-scoring
- PATCH /api/v1/manual-scoring/:scoreId
- GET /api/v1/manual-scoring/comparison/:videoId
- GET /api/v1/manual-scoring/export

**Deliverable**: Fully functional backend API with all endpoints

---

## Phase 3: Frontend UI (1.5-2 weeks)

### Step 3.1: Create API Service

**File**: `/Users/davidconroy/AIM/aim-coach-portal-ui/src/api/manualScoringService.js`

```javascript
import apiClient from './client';

const manualScoringService = {
  getUnscoredVideos: async (filters = {}) => { /* ... */ },
  getManualScoresByVideo: async (videoId) => { /* ... */ },
  createManualScore: async (scoreData) => { /* ... */ },
  updateManualScore: async (scoreId, updates) => { /* ... */ },
  getComparisonData: async (videoId) => { /* ... */ },
  getQualityMetrics: async () => { /* ... */ },
  exportScoringData: async (format, filters = {}) => { /* ... */ }
};

export default manualScoringService;
```

**Tests**: Create `src/api/__tests__/manualScoringService.test.js`

### Step 3.2: Create Scoring Dashboard Page

**File**: `/Users/davidconroy/AIM/aim-coach-portal-ui/src/pages/ManualScoringDashboard.jsx`

**Components**:
- Two tabs: "Score Videos" and "Quality Metrics"
- Filters: Drill type, search by player
- Video table with columns:
  - Player Name
  - Drill Type
  - Level
  - Upload Date
  - Manual Score Count
  - Actions (Score button)
- Pagination controls
- Export buttons (CSV/JSON)

**State Management**:
```javascript
const [videos, setVideos] = useState([]);
const [loading, setLoading] = useState(false);
const [filters, setFilters] = useState({ gameType: 'all', search: '' });
const [page, setPage] = useState(0);
const [rowsPerPage, setRowsPerPage] = useState(25);
```

**Key Functions**:
```javascript
const loadVideos = async () => { /* fetch and set videos */ };
const handleScoreVideo = (videoId) => { /* navigate to scoring interface */ };
const handleExport = async (format) => { /* download CSV/JSON */ };
```

### Step 3.3: Create Scoring Interface Page

**File**: `/Users/davidconroy/AIM/aim-coach-portal-ui/src/pages/ManualScoringInterface.jsx`

**Layout**:
- Left side (8 columns): Video player
- Right side (4 columns): Scoring form

**Components Used**:
- EnhancedVideoPlayer (reuse existing)
- ScoringForm (new component)
- Notes TextField
- Confidence/Difficulty Sliders
- Save Draft / Submit buttons

**State Management**:
```javascript
const [video, setVideo] = useState(null);
const [granularity, setGranularity] = useState('category');
const [scores, setScores] = useState({});
const [notes, setNotes] = useState('');
const [confidenceLevel, setConfidenceLevel] = useState(3);
const [difficultyRating, setDifficultyRating] = useState(3);
const [scoringStartTime, setScoringStartTime] = useState(Date.now());
```

**Key Functions**:
```javascript
const loadVideo = async () => { /* fetch video details */ };
const handleScoreChange = (newScores) => { /* update scores state */ };
const handleSaveDraft = async () => { /* POST with status: 'draft' */ };
const handleSubmit = async () => { /* validate + POST with status: 'submitted' */ };
const validateScores = () => { /* ensure all required scores present */ };
```

### Step 3.4: Create ScoringForm Component

**File**: `/Users/davidconroy/AIM/aim-coach-portal-ui/src/components/manualScoring/ScoringForm.jsx`

**Props**:
```javascript
{
  granularity: 'overall' | 'category' | 'metric' | 'activity',
  gameType: string,
  scores: object,
  onChange: (scores) => void
}
```

**Drill Configurations**:
```javascript
const DRILL_CONFIGS = {
  PASSING_RECEIVING_TURNING: {
    categories: {
      Dribbling: ['Ball Distance from Foot', 'No. of Touches', ...],
      'First Touch': [...],
      Passing: [...]
    }
  },
  TRIPLE_CONE_DRILL: {
    categories: {
      Dribbling: ['Speed to Complete', 'No. of Touches', ...]
    }
  },
  // ... other drill types
};
```

**Dynamic Form Rendering**:
- Overall: Single TextField (0-100)
- Category: TextField for each category
- Metric: Grouped TextFields by category with **TWO inputs per metric**:
  - Value field (raw measurement: e.g., "12.5" seconds, "15" touches, "0.35" meters)
  - Score field (0-100 subjective score)
- Activity: Activity list with score inputs

### Step 3.5: Create ComparisonView Component

**File**: `/Users/davidconroy/AIM/aim-coach-portal-ui/src/components/manualScoring/ComparisonView.jsx`

**Layout**:
- Dialog/Modal with full width
- Split view: AI Score | Manual Scores
- Difference table with color coding
- Close button

**Props**:
```javascript
{
  open: boolean,
  onClose: () => void,
  data: { manualScores: [], aiScore: {} },
  videoUrl: string
}
```

**Color Coding**:
- Green: Difference <5 points
- Yellow: Difference 5-10 points
- Red: Difference >10 points

### Step 3.6: Add Routes

**File**: `/Users/davidconroy/AIM/aim-coach-portal-ui/src/App.js`

Add imports:
```javascript
import ManualScoringDashboard from './pages/ManualScoringDashboard';
import ManualScoringInterface from './pages/ManualScoringInterface';
```

Add routes:
```javascript
<Route path="/manual-scoring" element={<ManualScoringDashboard />} />
<Route path="/manual-scoring/:videoId" element={<ManualScoringInterface />} />
```

### Step 3.7: Add Navigation Link

**File**: `/Users/davidconroy/AIM/aim-coach-portal-ui/src/components/AppLayout.jsx`

Add navigation item (visible only for PLATFORM_ADMIN):

```javascript
{isPlatformAdmin && (
  <ListItem button onClick={() => navigate('/manual-scoring')}>
    <ListItemIcon><AssessmentIcon /></ListItemIcon>
    <ListItemText primary="Manual Scoring" />
  </ListItem>
)}
```

**Deliverable**: Complete frontend UI integrated with backend API

---

## Phase 4: Testing & QA (1 week)

### Step 4.1: Unit Tests

**Backend**:
- Test DAO functions with mock MongoDB
- Test service validation logic
- Test CSV conversion functions
- Test score extraction helpers

**Frontend**:
- Test ScoringForm rendering for each granularity
- Test form validation
- Test API service calls

### Step 4.2: Integration Tests

**Backend**:
- Test API endpoints with supertest
- Test PLATFORM_ADMIN middleware
- Test score creation flow end-to-end
- Test export functionality

**Frontend**:
- Test navigation flow (dashboard → scoring → back)
- Test form submission and error handling
- Test export downloads

### Step 4.3: Manual Testing Scenarios

1. **Happy Path**:
   - Login as PLATFORM_ADMIN
   - Browse videos
   - Select video and score it
   - Save draft
   - Return and complete score
   - Submit score
   - View comparison
   - Export data

2. **Validation**:
   - Submit with missing scores
   - Submit with out-of-range values
   - Try to score same video twice
   - Try to update another coach's score

3. **Edge Cases**:
   - Video with no AI score
   - Video with multiple manual scores
   - Large dataset export (1000+ records)
   - Switch granularity mid-scoring

4. **Access Control**:
   - Try to access as non-admin (should fail)
   - Verify navigation link hidden for non-admins

### Step 4.4: Performance Testing

- Load dashboard with 1000+ videos
- Score 10 videos in sequence
- Export 1000 records
- Verify video player performance

### Step 4.5: UAT with Coaches

- Onboard 2-3 test coaches
- Have them score 5-10 videos each
- Collect feedback on UX
- Identify pain points
- Refine based on feedback

**Deliverable**: Tested and validated system ready for production

---

## Phase 5: Deployment (3-4 days)

### Step 5.1: Database Migration

**Staging**:
```bash
# Connect to staging MongoDB
# No migration needed for new collection
# Verify indexes are created automatically on first insert
```

**Production**:
```bash
# Deploy during low-traffic window
# Monitor for index creation performance
```

### Step 5.2: Backend Deployment

**Staging**:
```bash
cd /Users/davidconroy/AIM/aim-coach-portal-api
git checkout staging
git pull origin staging
npm install
npm run build  # if build step exists
pm2 restart aim-coach-portal-api-staging
```

**Verify**:
- Test API endpoints with Postman
- Check logs for errors
- Verify PLATFORM_ADMIN middleware working

**Production**:
```bash
git checkout master
git pull origin master
npm install
pm2 restart aim-coach-portal-api-production
```

### Step 5.3: Frontend Deployment

**Staging**:
```bash
cd /Users/davidconroy/AIM/aim-coach-portal-ui
git checkout staging
git pull origin staging
npm install
npm run build
# Deploy build/ to hosting (e.g., S3, Netlify, or server)
```

**Verify**:
- Access /manual-scoring page
- Test full user flow
- Check browser console for errors

**Production**:
```bash
git checkout master
git pull origin master
npm install
npm run build
# Deploy to production hosting
```

### Step 5.4: Smoke Testing

**Staging**:
- [ ] Login as PLATFORM_ADMIN
- [ ] Load dashboard
- [ ] Select video
- [ ] Submit score
- [ ] View comparison
- [ ] Export CSV
- [ ] Verify data in MongoDB

**Production**:
- [ ] Repeat smoke test in production
- [ ] Verify with real coach accounts

### Step 5.5: Monitoring

**Setup Alerts**:
- API error rate >5%
- Response time >3s
- Failed score submissions

**Logs to Monitor**:
- `/var/log/aim-coach-portal-api/error.log`
- `/var/log/aim-coach-portal-ui/access.log`
- MongoDB slow query log

**Metrics to Track**:
- Number of scores created per day
- Average scoring duration
- Export requests
- API response times

### Step 5.6: Documentation

- [ ] Update API documentation with production URLs
- [ ] Create user guide for coaches
- [ ] Document deployment process
- [ ] Update README with new feature

**Deliverable**: System deployed to production and monitored

---

## Post-Deployment Tasks

### Week 1:
- Monitor logs daily
- Track usage metrics
- Collect initial user feedback
- Fix any critical bugs

### Week 2-4:
- Analyze inter-rater reliability
- Identify model improvement opportunities
- Plan iterative enhancements
- Consider additional features (see Future Enhancements)

---

## Rollback Plan

If critical issues arise in production:

1. **Backend Rollback**:
   ```bash
   cd /Users/davidconroy/AIM/aim-coach-portal-api
   git checkout <previous-commit>
   pm2 restart aim-coach-portal-api-production
   ```

2. **Frontend Rollback**:
   ```bash
   cd /Users/davidconroy/AIM/aim-coach-portal-ui
   git checkout <previous-commit>
   npm run build
   # Deploy previous build
   ```

3. **Database Rollback**:
   - ManualScores collection is new, can be dropped if needed
   - No impact on existing collections

---

## Success Criteria

- [ ] All unit tests passing (>70% coverage)
- [ ] All integration tests passing
- [ ] UAT feedback addressed
- [ ] Performance benchmarks met
- [ ] Documentation complete
- [ ] Deployed to production
- [ ] 3+ coaches actively using system
- [ ] 50+ videos scored in first month

---

**Document Version**: 1.0
**Last Updated**: 2024-12-02
**Estimated Completion**: 5 weeks from start
