# API Specification - Manual Scoring Tool

## Base URL

```
http://localhost:4003/api/v1/manual-scoring
```

Production: `https://api.aimapps.com/api/v1/manual-scoring`

## Authentication

All endpoints require:
- **JWT Bearer Token** in Authorization header
- **PLATFORM_ADMIN** role

```http
Authorization: Bearer <jwt_token>
```

Non-admin users receive `403 Forbidden` error.

## Error Responses

All errors follow this format:

```json
{
  "success": false,
  "error": {
    "message": "Error description",
    "code": "ERROR_CODE",
    "details": {}
  }
}
```

Common error codes:
- `401`: Unauthorized (missing/invalid token)
- `403`: Forbidden (not PLATFORM_ADMIN)
- `400`: Bad Request (validation failure)
- `404`: Not Found
- `500`: Internal Server Error

---

## Endpoints

### 1. Get Unscored Videos

Get list of videos available for scoring.

**Endpoint**: `GET /api/v1/manual-scoring/videos`

**Query Parameters**:
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `gameType` | string | No | Filter by drill type (e.g., "TRIPLE_CONE_DRILL") |
| `limit` | number | No | Max videos to return (default: 50) |

**Response**: `200 OK`

```json
{
  "success": true,
  "data": [
    {
      "_id": "60d5ec49f1b2c8b1f8c4e123",
      "videoUrl": "https://storage.googleapis.com/...",
      "gameType": "TRIPLE_CONE_DRILL",
      "drillLevel": "level_two",
      "userId": "60a3d1e9f8b4c9a1234b5670",
      "playerName": "John Doe",
      "status": "PROCESSED",
      "createdAt": "2024-11-15T10:30:00Z",
      "manualScoreCount": 0
    }
  ]
}
```

**Example**:

```bash
curl -X GET "http://localhost:4003/api/v1/manual-scoring/videos?gameType=TRIPLE_CONE_DRILL&limit=25" \
  -H "Authorization: Bearer <token>"
```

---

### 2. Get Manual Scores for Video

Get all manual scores for a specific video.

**Endpoint**: `GET /api/v1/manual-scoring/video/:videoId`

**Path Parameters**:
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `videoId` | string | Yes | Video upload ID |

**Response**: `200 OK`

```json
{
  "success": true,
  "data": [
    {
      "_id": "507f1f77bcf86cd799439011",
      "videoUploadsId": "60d5ec49f1b2c8b1f8c4e123",
      "coachId": "60a3d1e9f8b4c9a1234b5678",
      "coachName": "John Smith",
      "gameType": "TRIPLE_CONE_DRILL",
      "granularity": "category",
      "scores": {
        "categories": {
          "Dribbling": 85
        }
      },
      "notes": "Good execution overall",
      "scoringDuration": 180,
      "createdAt": "2024-12-02T10:30:00Z",
      "updatedAt": "2024-12-02T10:33:00Z",
      "status": "submitted",
      "confidenceLevel": 4,
      "difficultyRating": 2
    }
  ]
}
```

**Example**:

```bash
curl -X GET "http://localhost:4003/api/v1/manual-scoring/video/60d5ec49f1b2c8b1f8c4e123" \
  -H "Authorization: Bearer <token>"
```

---

### 3. Create Manual Score

Create a new manual score for a video.

**Endpoint**: `POST /api/v1/manual-scoring`

**Request Body**:

```json
{
  "videoUploadsId": "60d5ec49f1b2c8b1f8c4e123",
  "gameType": "TRIPLE_CONE_DRILL",
  "granularity": "category",
  "scores": {
    "categories": {
      "Dribbling": 85
    }
  },
  "notes": "Good execution overall",
  "scoringDuration": 180,
  "status": "submitted",
  "confidenceLevel": 4,
  "difficultyRating": 2
}
```

**Request Body Schema**:

```typescript
{
  videoUploadsId: string;           // Required
  gameType: string;                 // Required (UPLOAD_VIDEO_GAME_TYPE enum)
  granularity: 'overall' | 'category' | 'metric' | 'activity'; // Required
  scores: object;                   // Required, structure varies by granularity
  notes?: string;                   // Optional
  scoringDuration: number;          // Required (seconds)
  status: 'draft' | 'submitted';    // Required
  confidenceLevel?: number;         // Optional (1-5)
  difficultyRating?: number;        // Optional (1-5)
}
```

**Granularity-Specific Score Structures**:

**Overall**:
```json
{
  "granularity": "overall",
  "scores": {
    "overall": 87
  }
}
```

**Category**:
```json
{
  "granularity": "category",
  "scores": {
    "categories": {
      "Dribbling": 85,
      "Passing": 92,
      "First Touch": 78
    }
  }
}
```

**Metric**:
```json
{
  "granularity": "metric",
  "scores": {
    "metrics": {
      "Dribbling": {
        "Ball Distance from Foot": {
          "value": 0.35,
          "score": 88
        },
        "No. of Touches": {
          "value": 15,
          "score": 92
        },
        "Speed to Complete": {
          "value": 12.5,
          "score": 85
        }
      },
      "Passing": {
        "Angle of Ball Return": {
          "value": 45,
          "score": 90
        }
      }
    }
  }
}
```

**Note**: For metric granularity, each metric includes:
- `value`: The raw measured value (e.g., 12.5 seconds, 15 touches, 0.35 meters)
- `score`: The subjective score (0-100) based on that value

**Activity**:
```json
{
  "granularity": "activity",
  "scores": {
    "activities": [
      {
        "activityIndex": 0,
        "type": "Dribbling",
        "score": 85,
        "frames": { "start": 0, "end": 120 }
      },
      {
        "activityIndex": 1,
        "type": "Passing",
        "score": 92,
        "frames": { "start": 121, "end": 180 }
      }
    ]
  }
}
```

**Response**: `201 Created`

```json
{
  "success": true,
  "data": {
    "_id": "507f1f77bcf86cd799439011",
    "videoUploadsId": "60d5ec49f1b2c8b1f8c4e123",
    "coachId": "60a3d1e9f8b4c9a1234b5678",
    "coachName": "John Smith",
    "gameType": "TRIPLE_CONE_DRILL",
    "granularity": "category",
    "scores": {
      "categories": {
        "Dribbling": 85
      }
    },
    "notes": "Good execution overall",
    "scoringDuration": 180,
    "createdAt": "2024-12-02T10:30:00Z",
    "updatedAt": "2024-12-02T10:33:00Z",
    "status": "submitted",
    "confidenceLevel": 4,
    "difficultyRating": 2
  }
}
```

**Validation Errors**: `400 Bad Request`

```json
{
  "success": false,
  "error": {
    "message": "Overall score must be between 0-100",
    "code": "VALIDATION_ERROR"
  }
}
```

**Duplicate Error**: `400 Bad Request`

```json
{
  "success": false,
  "error": {
    "message": "You have already scored this video",
    "code": "DUPLICATE_SCORE"
  }
}
```

**Example**:

```bash
curl -X POST "http://localhost:4003/api/v1/manual-scoring" \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{
    "videoUploadsId": "60d5ec49f1b2c8b1f8c4e123",
    "gameType": "TRIPLE_CONE_DRILL",
    "granularity": "overall",
    "scores": { "overall": 87 },
    "notes": "Excellent performance",
    "scoringDuration": 120,
    "status": "submitted",
    "confidenceLevel": 5,
    "difficultyRating": 2
  }'
```

---

### 4. Update Manual Score

Update an existing manual score (must be owner).

**Endpoint**: `PATCH /api/v1/manual-scoring/:scoreId`

**Path Parameters**:
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `scoreId` | string | Yes | Manual score ID |

**Request Body**:

```json
{
  "scores": {
    "overall": 90
  },
  "notes": "Updated after review",
  "confidenceLevel": 5,
  "status": "submitted"
}
```

All fields are optional. Only provided fields will be updated.

**Response**: `200 OK`

```json
{
  "success": true,
  "data": {
    "_id": "507f1f77bcf86cd799439011",
    "videoUploadsId": "60d5ec49f1b2c8b1f8c4e123",
    "coachId": "60a3d1e9f8b4c9a1234b5678",
    "coachName": "John Smith",
    "gameType": "TRIPLE_CONE_DRILL",
    "granularity": "overall",
    "scores": {
      "overall": 90
    },
    "notes": "Updated after review",
    "scoringDuration": 180,
    "createdAt": "2024-12-02T10:30:00Z",
    "updatedAt": "2024-12-02T10:45:00Z",
    "status": "submitted",
    "confidenceLevel": 5,
    "difficultyRating": 2
  }
}
```

**Errors**:

`403 Forbidden` - Not the score owner:
```json
{
  "success": false,
  "error": {
    "message": "Cannot update another coach's score",
    "code": "FORBIDDEN"
  }
}
```

`404 Not Found` - Score doesn't exist:
```json
{
  "success": false,
  "error": {
    "message": "Manual score not found",
    "code": "NOT_FOUND"
  }
}
```

**Example**:

```bash
curl -X PATCH "http://localhost:4003/api/v1/manual-scoring/507f1f77bcf86cd799439011" \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{
    "scores": { "overall": 90 },
    "notes": "Updated score",
    "status": "submitted"
  }'
```

---

### 5. Get Comparison Data

Get AI vs manual score comparison for a video.

**Endpoint**: `GET /api/v1/manual-scoring/comparison/:videoId`

**Path Parameters**:
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `videoId` | string | Yes | Video upload ID |

**Response**: `200 OK`

```json
{
  "success": true,
  "data": {
    "manualScores": [
      {
        "_id": "507f1f77bcf86cd799439011",
        "coachId": "60a3d1e9f8b4c9a1234b5678",
        "coachName": "John Smith",
        "granularity": "category",
        "scores": {
          "categories": {
            "Dribbling": 85,
            "Passing": 92
          }
        },
        "createdAt": "2024-12-02T10:30:00Z"
      }
    ],
    "aiScore": {
      "_id": "60d5ec49f1b2c8b1f8c4e200",
      "total_score": 88,
      "areas": {
        "area_1": {
          "Dribbling": {
            "scores": {
              "Ball Distance from Foot": { "score": 85 },
              "No. of Touches": { "score": 90 }
            }
          }
        }
      },
      "activity_timeline": {
        "activities": [
          {
            "type": "Dribbling",
            "raw_score": 85,
            "frames": { "start": 0, "end": 120 }
          }
        ]
      }
    }
  }
}
```

**Example**:

```bash
curl -X GET "http://localhost:4003/api/v1/manual-scoring/comparison/60d5ec49f1b2c8b1f8c4e123" \
  -H "Authorization: Bearer <token>"
```

---

### 6. Get Quality Metrics

Get inter-rater reliability and coach statistics.

**Endpoint**: `GET /api/v1/manual-scoring/quality-metrics`

**Response**: `200 OK`

```json
{
  "success": true,
  "data": {
    "multiScoredVideos": [
      {
        "_id": "60d5ec49f1b2c8b1f8c4e123",
        "count": 3,
        "scores": [
          { "overall": 85 },
          { "overall": 88 },
          { "overall": 86 }
        ],
        "coaches": ["John Smith", "Sarah Jones", "Mike Brown"],
        "standardDeviation": 1.53,
        "meanScore": 86.33
      }
    ],
    "coachStats": [
      {
        "_id": "60a3d1e9f8b4c9a1234b5678",
        "coachName": "John Smith",
        "totalScored": 45,
        "avgDuration": 195.5,
        "avgConfidence": 4.2
      },
      {
        "_id": "60a3d1e9f8b4c9a1234b5679",
        "coachName": "Sarah Jones",
        "totalScored": 38,
        "avgDuration": 210.3,
        "avgConfidence": 4.5
      }
    ]
  }
}
```

**Example**:

```bash
curl -X GET "http://localhost:4003/api/v1/manual-scoring/quality-metrics" \
  -H "Authorization: Bearer <token>"
```

---

### 7. Export Scoring Data

Export manual scores with AI scores for ML training.

**Endpoint**: `GET /api/v1/manual-scoring/export`

**Query Parameters**:
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `format` | string | No | 'json' or 'csv' (default: 'json') |
| `gameType` | string | No | Filter by drill type |
| `startDate` | string | No | ISO date (e.g., "2024-01-01") |
| `endDate` | string | No | ISO date (e.g., "2024-12-31") |

**Response (JSON)**: `200 OK`

```json
{
  "success": true,
  "data": [
    {
      "videoId": "60d5ec49f1b2c8b1f8c4e123",
      "videoUrl": "https://storage.googleapis.com/...",
      "gameType": "TRIPLE_CONE_DRILL",
      "coachId": "60a3d1e9f8b4c9a1234b5678",
      "coachName": "John Smith",
      "granularity": "overall",
      "manualScores": {
        "overall": 87
      },
      "aiScores": {
        "total_score": 85,
        "areas": {},
        "activity_timeline": {}
      },
      "notes": "Excellent performance",
      "createdAt": "2024-12-02T10:30:00Z",
      "scoringDuration": 180,
      "confidenceLevel": 5
    }
  ]
}
```

**Response (CSV)**: `200 OK`

```
Content-Type: text/csv
Content-Disposition: attachment; filename=manual-scores.csv

videoId,videoUrl,gameType,coachId,coachName,granularity,manualScore,aiScore,difference,notes,createdAt
60d5ec49f1b2c8b1f8c4e123,https://storage.googleapis.com/...,TRIPLE_CONE_DRILL,60a3d1e9f8b4c9a1234b5678,John Smith,overall,87,85,2,Excellent performance,2024-12-02T10:30:00Z
```

**Example (JSON)**:

```bash
curl -X GET "http://localhost:4003/api/v1/manual-scoring/export?format=json&gameType=TRIPLE_CONE_DRILL" \
  -H "Authorization: Bearer <token>"
```

**Example (CSV)**:

```bash
curl -X GET "http://localhost:4003/api/v1/manual-scoring/export?format=csv&startDate=2024-11-01&endDate=2024-12-31" \
  -H "Authorization: Bearer <token>" \
  --output manual-scores.csv
```

---

## Rate Limiting

- **Rate Limit**: 100 requests per minute per user
- **Headers**:
  - `X-RateLimit-Limit`: Maximum requests allowed
  - `X-RateLimit-Remaining`: Requests remaining
  - `X-RateLimit-Reset`: Timestamp when limit resets

**429 Too Many Requests**:
```json
{
  "success": false,
  "error": {
    "message": "Rate limit exceeded. Try again in 30 seconds.",
    "code": "RATE_LIMIT_EXCEEDED"
  }
}
```

---

## Pagination

For endpoints returning lists (if implemented):

**Query Parameters**:
- `page`: Page number (default: 1)
- `limit`: Items per page (default: 25, max: 100)

**Response Headers**:
- `X-Total-Count`: Total number of items
- `X-Page`: Current page number
- `X-Page-Count`: Total number of pages

---

## Versioning

API version is included in the URL: `/api/v1/...`

Future versions will be released as `/api/v2/...` with backwards compatibility maintained for v1.

---

## Postman Collection

Import this collection for testing:

```json
{
  "info": {
    "name": "Manual Scoring API",
    "schema": "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"
  },
  "item": [
    {
      "name": "Get Unscored Videos",
      "request": {
        "method": "GET",
        "url": "{{baseUrl}}/manual-scoring/videos?gameType=TRIPLE_CONE_DRILL",
        "header": [
          { "key": "Authorization", "value": "Bearer {{token}}" }
        ]
      }
    }
  ]
}
```

---

**Document Version**: 1.0
**Last Updated**: 2024-12-02
**API Version**: v1
