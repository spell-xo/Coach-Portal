# Deployment Guide - Manual Scoring Tool

## Overview

This guide provides step-by-step instructions for deploying the manual scoring tool to staging and production environments.

## Prerequisites

- [ ] All code merged to `master` branch
- [ ] All tests passing locally
- [ ] Database migration plan reviewed
- [ ] Deployment window scheduled
- [ ] Rollback plan prepared
- [ ] Team notified of deployment

## Deployment Environments

| Environment | Purpose | URL | Database |
|-------------|---------|-----|----------|
| **Local** | Development | http://localhost:4003 | Local MongoDB |
| **Staging** | QA Testing | https://staging-api.aimapps.com | Staging MongoDB |
| **Production** | Live System | https://api.aimapps.com | Production MongoDB |

---

## Phase 1: Pre-Deployment Checklist

### Code Review

- [ ] All PRs reviewed and approved
- [ ] Code follows existing patterns
- [ ] No hardcoded values or secrets
- [ ] Error handling implemented
- [ ] Logging added for key operations
- [ ] Comments added for complex logic

### Testing

- [ ] Unit tests passing (`npm test`)
- [ ] Integration tests passing
- [ ] Manual testing completed
- [ ] UAT feedback addressed
- [ ] Performance benchmarks met
- [ ] Browser compatibility verified

### Documentation

- [ ] API documentation updated
- [ ] Code comments added
- [ ] README updated with new feature
- [ ] Deployment steps documented
- [ ] Rollback procedure documented

### Database

- [ ] Schema changes reviewed
- [ ] Indexes planned
- [ ] Migration scripts prepared (if needed)
- [ ] Backup plan confirmed

### Configuration

- [ ] Environment variables defined
- [ ] Secrets added to secure storage
- [ ] Feature flags configured (if applicable)
- [ ] Monitoring alerts configured

---

## Phase 2: Staging Deployment

### Step 2.1: Database Preparation (Staging)

**Connect to Staging MongoDB**:
```bash
mongo "mongodb://staging-mongo.aimapps.com:27017/aim_database" --username admin --password <password>
```

**Verify Collections**:
```javascript
use aim_database
show collections
// Verify manualscores collection will be created on first insert
```

**No migration needed** - new collection will be created automatically with correct indexes.

### Step 2.2: Backend Deployment (Staging)

**1. SSH to Staging Server**:
```bash
ssh aim-staging-server
```

**2. Navigate to Project**:
```bash
cd /var/www/aim-coach-portal-api
```

**3. Backup Current Version**:
```bash
git branch backup-$(date +%Y%m%d-%H%M%S)
```

**4. Pull Latest Code**:
```bash
git checkout staging
git pull origin staging
```

**5. Install Dependencies**:
```bash
npm install
```

**6. Verify aim-common-plugin Updated**:
```bash
npm list aim-common-plugin
# Should show latest version with ManualScores schema
```

**7. Restart Application**:
```bash
pm2 restart aim-coach-portal-api-staging
```

**8. Verify Startup**:
```bash
pm2 logs aim-coach-portal-api-staging --lines 50
# Look for "Server running on port 4003"
# Check for any errors
```

**9. Test Health Endpoint**:
```bash
curl https://staging-api.aimapps.com/health
# Expected: {"status": "healthy"}
```

### Step 2.3: Frontend Deployment (Staging)

**1. SSH to Staging Server**:
```bash
ssh aim-staging-ui-server
```

**2. Navigate to Project**:
```bash
cd /var/www/aim-coach-portal-ui
```

**3. Pull Latest Code**:
```bash
git checkout staging
git pull origin staging
```

**4. Install Dependencies**:
```bash
npm install
```

**5. Build Application**:
```bash
npm run build
# This creates optimized production build in build/ directory
```

**6. Deploy Build**:
```bash
# If using Nginx
sudo cp -r build/* /var/www/html/aim-coach-portal-ui-staging/

# If using S3
aws s3 sync build/ s3://aim-coach-portal-ui-staging/

# If using PM2 serve
pm2 restart aim-coach-portal-ui-staging
```

**7. Clear CDN Cache** (if applicable):
```bash
# CloudFlare example
curl -X POST "https://api.cloudflare.com/client/v4/zones/<zone_id>/purge_cache" \
  -H "Authorization: Bearer <api_token>" \
  -H "Content-Type: application/json" \
  -d '{"purge_everything":true}'
```

### Step 2.4: Smoke Testing (Staging)

**Backend API Tests**:
```bash
# Get auth token for PLATFORM_ADMIN user
TOKEN="<get_from_login>"

# Test videos endpoint
curl -X GET "https://staging-api.aimapps.com/api/v1/manual-scoring/videos" \
  -H "Authorization: Bearer $TOKEN"

# Test create score
curl -X POST "https://staging-api.aimapps.com/api/v1/manual-scoring" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "videoUploadsId": "<test_video_id>",
    "gameType": "TRIPLE_CONE_DRILL",
    "granularity": "overall",
    "scores": {"overall": 85},
    "scoringDuration": 120,
    "status": "submitted"
  }'

# Test export
curl -X GET "https://staging-api.aimapps.com/api/v1/manual-scoring/export?format=json" \
  -H "Authorization: Bearer $TOKEN"
```

**Frontend UI Tests**:
1. Open https://staging.aimapps.com/manual-scoring
2. Login as PLATFORM_ADMIN
3. Verify dashboard loads
4. Click on a video
5. Enter scores
6. Submit
7. Verify success message
8. Check comparison view
9. Test export

**Verify in Database**:
```javascript
use aim_database
db.manualscores.find().limit(5).pretty()
// Verify records created correctly

db.manualscores.getIndexes()
// Verify indexes created
```

### Step 2.5: Staging Sign-off

- [ ] All smoke tests passed
- [ ] No errors in logs
- [ ] Database records verified
- [ ] Performance acceptable
- [ ] UI rendering correctly
- [ ] UAT team notified to begin testing

---

## Phase 3: Production Deployment

### Step 3.1: Pre-Production Checklist

- [ ] Staging testing complete (minimum 2 days)
- [ ] All bugs fixed
- [ ] Performance validated
- [ ] Team ready for deployment
- [ ] Rollback plan reviewed
- [ ] Deployment window confirmed (off-peak hours)

### Step 3.2: Production Deployment Window

**Recommended Time**:
- Weekday: 10:00 PM - 2:00 AM (local time)
- Weekend: Anytime with team availability

**Duration**: 30-60 minutes

**Team Required**:
- Backend Developer
- Frontend Developer
- DevOps Engineer
- QA Engineer (for verification)

### Step 3.3: Backend Deployment (Production)

**1. Announce Deployment**:
```
# Post to team Slack channel
@channel Starting production deployment of manual scoring tool.
ETA: 30 minutes. Monitoring active.
```

**2. Take Database Backup**:
```bash
# On production MongoDB server
mongodump --uri="mongodb://prod-mongo.aimapps.com:27017/aim_database" \
  --out=/backups/aim-$(date +%Y%m%d-%H%M%S)
```

**3. SSH to Production Server**:
```bash
ssh aim-production-server
```

**4. Backup Current Code**:
```bash
cd /var/www/aim-coach-portal-api
git branch backup-production-$(date +%Y%m%d-%H%M%S)
git tag pre-manual-scoring-deployment
```

**5. Pull Latest Code**:
```bash
git checkout master
git pull origin master
```

**6. Install Dependencies**:
```bash
npm install --production
```

**7. Run Pre-Deployment Tests** (optional):
```bash
NODE_ENV=production npm test
```

**8. Restart Application with Zero Downtime**:
```bash
# If using PM2 cluster mode
pm2 reload aim-coach-portal-api-production

# If not using cluster mode
pm2 restart aim-coach-portal-api-production
```

**9. Monitor Logs**:
```bash
pm2 logs aim-coach-portal-api-production --lines 100
# Watch for errors during startup
```

**10. Verify Health**:
```bash
curl https://api.aimapps.com/health
```

### Step 3.4: Frontend Deployment (Production)

**1. SSH to Production UI Server**:
```bash
ssh aim-production-ui-server
```

**2. Backup Current Build**:
```bash
cd /var/www/aim-coach-portal-ui
tar -czf build-backup-$(date +%Y%m%d-%H%M%S).tar.gz build/
```

**3. Pull Latest Code**:
```bash
git checkout master
git pull origin master
```

**4. Install Dependencies**:
```bash
npm install --production
```

**5. Build Application**:
```bash
npm run build
```

**6. Deploy Build**:
```bash
# Atomic deployment (reduces downtime)
sudo mv /var/www/html/aim-coach-portal-ui /var/www/html/aim-coach-portal-ui-old
sudo cp -r build /var/www/html/aim-coach-portal-ui
sudo rm -rf /var/www/html/aim-coach-portal-ui-old
```

**7. Clear CDN Cache**:
```bash
# Clear edge caches
curl -X POST "https://api.cloudflare.com/client/v4/zones/<zone_id>/purge_cache" \
  -H "Authorization: Bearer <api_token>" \
  -H "Content-Type: application/json" \
  -d '{"purge_everything":true}'
```

### Step 3.5: Production Smoke Testing

**Backend API Tests**:
```bash
# Same as staging but with production URLs
TOKEN="<production_admin_token>"

curl -X GET "https://api.aimapps.com/api/v1/manual-scoring/videos" \
  -H "Authorization: Bearer $TOKEN"
```

**Frontend UI Tests**:
1. Open https://app.aimapps.com/manual-scoring
2. Login as PLATFORM_ADMIN
3. Complete full scoring flow
4. Verify database record created
5. Test export functionality

**Database Verification**:
```javascript
use aim_database
db.manualscores.find().limit(1).pretty()
db.manualscores.getIndexes()
```

### Step 3.6: Post-Deployment Monitoring

**Immediate (First Hour)**:
- [ ] Monitor error logs every 10 minutes
- [ ] Check response times (should be <1s)
- [ ] Verify no 500 errors
- [ ] Monitor database connections
- [ ] Watch for memory leaks

**First 24 Hours**:
- [ ] Check logs every 2 hours
- [ ] Monitor error rates
- [ ] Track API usage metrics
- [ ] Verify no performance degradation
- [ ] Collect user feedback

**First Week**:
- [ ] Daily log reviews
- [ ] Weekly usage reports
- [ ] Track scoring volumes
- [ ] Monitor inter-rater reliability
- [ ] Gather coach feedback

### Step 3.7: Deployment Announcement

```
# Post to team Slack
@channel Production deployment of manual scoring tool complete! ✅

What's new:
- Manual scoring interface at /manual-scoring (PLATFORM_ADMIN only)
- AI vs manual score comparison
- CSV/JSON export for training datasets
- Quality metrics dashboard

All systems operational. Monitoring active.

Any issues, please report immediately.
```

---

## Phase 4: Rollback Procedure

If critical issues are discovered, follow this rollback procedure:

### Step 4.1: Assess Severity

**Critical Issues** (immediate rollback):
- System down or unresponsive
- Data corruption
- Security vulnerability
- Cannot create manual scores

**Non-Critical Issues** (hotfix instead of rollback):
- UI glitches
- Minor functionality bugs
- Performance issues (if tolerable)

### Step 4.2: Backend Rollback

**1. SSH to Production Server**:
```bash
ssh aim-production-server
cd /var/www/aim-coach-portal-api
```

**2. Revert to Previous Version**:
```bash
git checkout pre-manual-scoring-deployment
# or
git checkout <previous-commit-hash>
```

**3. Reinstall Dependencies** (if needed):
```bash
npm install --production
```

**4. Restart Application**:
```bash
pm2 restart aim-coach-portal-api-production
```

**5. Verify Rollback**:
```bash
pm2 logs aim-coach-portal-api-production --lines 50
curl https://api.aimapps.com/health
```

### Step 4.3: Frontend Rollback

**1. SSH to Production UI Server**:
```bash
ssh aim-production-ui-server
cd /var/www/aim-coach-portal-ui
```

**2. Restore Previous Build**:
```bash
# Find backup
ls -lt build-backup-*.tar.gz | head -1

# Extract
tar -xzf build-backup-<timestamp>.tar.gz

# Deploy
sudo rm -rf /var/www/html/aim-coach-portal-ui
sudo cp -r build /var/www/html/aim-coach-portal-ui
```

**3. Clear CDN Cache**:
```bash
# Clear caches as in deployment
```

### Step 4.4: Database Rollback (if needed)

**Only if data corruption occurred**:

```bash
# Restore from backup
mongorestore --uri="mongodb://prod-mongo.aimapps.com:27017/aim_database" \
  --dir=/backups/aim-<backup-timestamp> \
  --drop

# Or drop only manualscores collection
mongo "mongodb://prod-mongo.aimapps.com:27017/aim_database"
use aim_database
db.manualscores.drop()
```

### Step 4.5: Post-Rollback

- [ ] Verify all systems operational
- [ ] Notify team of rollback
- [ ] Document root cause
- [ ] Plan hotfix deployment
- [ ] Update deployment checklist with lessons learned

---

## Monitoring & Alerts

### Key Metrics to Monitor

**API Performance**:
- Response time: <1s (warning), <2s (critical)
- Error rate: <1% (warning), <5% (critical)
- Request volume: Track baseline

**Database**:
- Connection pool utilization
- Query execution time
- Index usage
- Disk space

**Application**:
- CPU usage: <70% (warning), <90% (critical)
- Memory usage: <80% (warning), <95% (critical)
- PM2 restart count
- Uptime

### Alert Configuration

**PagerDuty / Opsgenie** alerts for:
- API error rate >5%
- Response time >3s for 5 minutes
- Application crash/restart
- Database connection failures
- Disk space <10%

**Slack notifications** for:
- New manual scores created
- Export requests (for auditing)
- Quality metrics thresholds (inter-rater reliability <0.7)

### Log Locations

**Backend**:
```bash
# Application logs
/var/log/aim-coach-portal-api/app.log
/var/log/aim-coach-portal-api/error.log

# PM2 logs
~/.pm2/logs/aim-coach-portal-api-production-out.log
~/.pm2/logs/aim-coach-portal-api-production-error.log
```

**Frontend**:
```bash
# Nginx access logs
/var/log/nginx/aim-coach-portal-ui-access.log

# Nginx error logs
/var/log/nginx/aim-coach-portal-ui-error.log
```

**Database**:
```bash
# MongoDB logs
/var/log/mongodb/mongod.log
```

---

## Troubleshooting

### Issue: API returns 403 Forbidden

**Cause**: User not PLATFORM_ADMIN

**Solution**:
1. Verify user has PLATFORM_ADMIN role in database
2. Check JWT token includes role
3. Verify middleware logic in platformAdminMiddleware.js

### Issue: Video player not loading

**Cause**: CORS or GCS permissions

**Solution**:
1. Check CORS headers in API response
2. Verify GCS bucket permissions
3. Check video URL format and accessibility

### Issue: Export timing out

**Cause**: Too many records

**Solution**:
1. Implement pagination for exports
2. Increase timeout in API
3. Use streaming for large datasets

### Issue: Scores not saving

**Cause**: Validation error or database issue

**Solution**:
1. Check API logs for validation errors
2. Verify MongoDB connection
3. Check if unique index constraint violated

### Issue: Dashboard loading slowly

**Cause**: Too many videos, missing indexes

**Solution**:
1. Verify indexes exist on videoUploads collection
2. Implement pagination
3. Add caching layer
4. Optimize aggregation queries

---

## Post-Deployment Checklist

- [ ] Deployment completed successfully
- [ ] Smoke tests passed
- [ ] Monitoring active
- [ ] Alerts configured
- [ ] Team notified
- [ ] Documentation updated
- [ ] Rollback plan tested (in staging)
- [ ] User training scheduled
- [ ] Feedback collection process in place

---

**Document Version**: 1.0
**Last Updated**: 2024-12-02
**Next Review**: After first production deployment
