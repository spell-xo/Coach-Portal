# Testing Strategy - Manual Scoring Tool

## Overview

This document outlines the testing approach for the manual scoring tool, including unit tests, integration tests, and manual testing procedures.

## Test Coverage Goals

- **Unit Tests**: >70% code coverage
- **Integration Tests**: All API endpoints and critical paths
- **Manual Tests**: Complete user flows and edge cases
- **Performance Tests**: Key metrics validated

---

## Unit Tests

### Backend Unit Tests

#### DAO Layer Tests (`tests/unit/manualScoringDAO.test.js`)

**Test Suite**: manualScoringDAO

**Mock Dependencies**:
- MongoDB/Mongoose models
- getModel() function from aim-common-plugin

**Test Cases**:

```javascript
describe('manualScoringDAO', () => {
  describe('createManualScore', () => {
    it('should create a new manual score', async () => {
      // Arrange: Mock ManualScores.create()
      // Act: Call createManualScore()
      // Assert: Verify correct data passed to create()
    });

    it('should throw error on duplicate coach-video pair', async () => {
      // Arrange: Mock duplicate key error
      // Act: Call createManualScore()
      // Assert: Verify error thrown
    });
  });

  describe('getManualScoresByVideo', () => {
    it('should return all scores for a video', async () => {
      // Arrange: Mock ManualScores.find()
      // Act: Call getManualScoresByVideo(videoId)
      // Assert: Verify correct videoId filter used
    });

    it('should return empty array if no scores found', async () => {
      // Arrange: Mock empty result
      // Act: Call getManualScoresByVideo(videoId)
      // Assert: Verify empty array returned
    });
  });

  describe('getUnscoredVideos', () => {
    it('should return processed videos with score count', async () => {
      // Arrange: Mock VideoUploads.find() and ManualScores.countDocuments()
      // Act: Call getUnscoredVideos()
      // Assert: Verify manualScoreCount added to each video
    });

    it('should filter by gameType', async () => {
      // Arrange: Mock with gameType filter
      // Act: Call getUnscoredVideos({ gameType: 'TRIPLE_CONE_DRILL' })
      // Assert: Verify filter applied
    });
  });

  describe('getQualityMetrics', () => {
    it('should calculate inter-rater reliability', async () => {
      // Arrange: Mock aggregation result
      // Act: Call getQualityMetrics()
      // Assert: Verify aggregation pipeline correct
    });

    it('should return coach statistics', async () => {
      // Arrange: Mock aggregation result
      // Act: Call getQualityMetrics()
      // Assert: Verify coach stats structure
    });
  });

  describe('exportScoringData', () => {
    it('should join manual scores with video and AI scores', async () => {
      // Arrange: Mock all related collections
      // Act: Call exportScoringData()
      // Assert: Verify data structure includes all fields
    });
  });
});
```

#### Service Layer Tests (`tests/unit/manualScoringService.test.js`)

**Test Suite**: manualScoringService

**Mock Dependencies**:
- manualScoringDAO functions

**Test Cases**:

```javascript
describe('manualScoringService', () => {
  describe('createManualScore', () => {
    it('should validate score data before creating', async () => {
      // Arrange: Valid score data
      // Act: Call createManualScore()
      // Assert: Verify validation passes and DAO called
    });

    it('should reject invalid granularity', async () => {
      // Arrange: Invalid granularity
      // Act: Call createManualScore()
      // Assert: Verify ApiError thrown with 400 status
    });

    it('should reject out-of-range scores', async () => {
      // Arrange: Score > 100
      // Act: Call createManualScore({ overall: 150 })
      // Assert: Verify ApiError thrown
    });

    it('should add coachId and timestamps', async () => {
      // Arrange: Score data without coach info
      // Act: Call createManualScore(data, coachId, coachName)
      // Assert: Verify coachId added to data
    });
  });

  describe('validateScoreData', () => {
    it('should validate overall score', () => {
      // Test cases: valid (0-100), invalid (negative, >100, null)
    });

    it('should validate category scores', () => {
      // Test cases: all categories present, values in range
    });

    it('should validate metric scores', () => {
      // Test cases: nested structure correct, all values valid
    });

    it('should validate activity scores', () => {
      // Test cases: array format, frame numbers, activity types
    });
  });

  describe('convertToCSV', () => {
    it('should convert JSON array to CSV string', () => {
      // Arrange: Array of export data
      // Act: Call convertToCSV()
      // Assert: Verify CSV format with headers
    });

    it('should handle missing fields gracefully', () => {
      // Arrange: Data with null/undefined fields
      // Act: Call convertToCSV()
      // Assert: Verify empty values in CSV
    });
  });

  describe('extractOverallScore', () => {
    it('should extract overall score when present', () => {
      // Arrange: { overall: 85 }
      // Act: extractOverallScore()
      // Assert: Return 85
    });

    it('should average category scores', () => {
      // Arrange: { categories: { Dribbling: 80, Passing: 90 } }
      // Act: extractOverallScore()
      // Assert: Return 85
    });

    it('should handle activity scores', () => {
      // Arrange: activities array
      // Act: extractOverallScore()
      // Assert: Return average of activity scores
    });
  });

  describe('updateManualScore', () => {
    it('should check ownership before updating', async () => {
      // Arrange: Different coachId
      // Act: Call updateManualScore()
      // Assert: Verify ApiError 403 thrown
    });

    it('should allow owner to update', async () => {
      // Arrange: Same coachId
      // Act: Call updateManualScore()
      // Assert: Verify DAO update called
    });
  });
});
```

### Frontend Unit Tests

#### API Service Tests (`src/api/__tests__/manualScoringService.test.js`)

```javascript
describe('manualScoringService', () => {
  it('should fetch unscored videos', async () => {
    // Mock apiClient.get()
    // Call getUnscoredVideos()
    // Verify correct endpoint and params
  });

  it('should create manual score', async () => {
    // Mock apiClient.post()
    // Call createManualScore()
    // Verify request body structure
  });

  it('should handle API errors', async () => {
    // Mock API error response
    // Call any service method
    // Verify error thrown/handled
  });
});
```

#### Component Tests (React Testing Library)

**ScoringForm Tests**:

```javascript
describe('ScoringForm', () => {
  it('should render overall input when granularity is overall', () => {
    render(<ScoringForm granularity="overall" scores={{}} onChange={() => {}} />);
    expect(screen.getByLabelText(/Overall Score/i)).toBeInTheDocument();
  });

  it('should render category inputs when granularity is category', () => {
    render(<ScoringForm granularity="category" gameType="PASSING_RECEIVING_TURNING" scores={{}} onChange={() => {}} />);
    expect(screen.getByLabelText(/Dribbling/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Passing/i)).toBeInTheDocument();
  });

  it('should validate numeric input', () => {
    const onChange = jest.fn();
    render(<ScoringForm granularity="overall" scores={{}} onChange={onChange} />);
    const input = screen.getByLabelText(/Overall Score/i);
    fireEvent.change(input, { target: { value: '85' } });
    expect(onChange).toHaveBeenCalledWith({ overall: 85 });
  });

  it('should reject invalid input', () => {
    const onChange = jest.fn();
    render(<ScoringForm granularity="overall" scores={{}} onChange={onChange} />);
    const input = screen.getByLabelText(/Overall Score/i);
    fireEvent.change(input, { target: { value: '150' } });
    // Verify validation error shown
  });
});
```

**Dashboard Tests**:

```javascript
describe('ManualScoringDashboard', () => {
  it('should load videos on mount', async () => {
    // Mock manualScoringService.getUnscoredVideos()
    render(<ManualScoringDashboard />);
    await waitFor(() => {
      expect(screen.getByText(/Videos/i)).toBeInTheDocument();
    });
  });

  it('should filter videos by drill type', async () => {
    // Mock API call
    render(<ManualScoringDashboard />);
    const filter = screen.getByLabelText(/Drill Type/i);
    fireEvent.change(filter, { target: { value: 'TRIPLE_CONE_DRILL' } });
    // Verify API called with filter
  });
});
```

---

## Integration Tests

### Backend Integration Tests

**Setup**:
```javascript
// Test database connection
beforeAll(async () => {
  await connectToTestDatabase();
});

afterAll(async () => {
  await disconnectFromDatabase();
});

beforeEach(async () => {
  await clearCollections();
});
```

**Test Suite**: Manual Scoring API (`tests/integration/manualScoring.test.js`)

```javascript
describe('Manual Scoring API Integration', () => {
  let authToken;
  let testVideo;

  beforeEach(async () => {
    // Create test PLATFORM_ADMIN user
    authToken = await getAdminAuthToken();
    // Create test video
    testVideo = await createTestVideo();
  });

  describe('GET /api/v1/manual-scoring/videos', () => {
    it('should return unscored videos', async () => {
      const response = await request(app)
        .get('/api/v1/manual-scoring/videos')
        .set('Authorization', `Bearer ${authToken}`)
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(Array.isArray(response.body.data)).toBe(true);
    });

    it('should require authentication', async () => {
      await request(app)
        .get('/api/v1/manual-scoring/videos')
        .expect(401);
    });

    it('should require PLATFORM_ADMIN role', async () => {
      const regularUserToken = await getRegularUserToken();
      await request(app)
        .get('/api/v1/manual-scoring/videos')
        .set('Authorization', `Bearer ${regularUserToken}`)
        .expect(403);
    });
  });

  describe('POST /api/v1/manual-scoring', () => {
    it('should create manual score', async () => {
      const scoreData = {
        videoUploadsId: testVideo._id.toString(),
        gameType: 'TRIPLE_CONE_DRILL',
        granularity: 'overall',
        scores: { overall: 85 },
        notes: 'Test score',
        scoringDuration: 120,
        status: 'submitted',
        confidenceLevel: 4,
        difficultyRating: 2
      };

      const response = await request(app)
        .post('/api/v1/manual-scoring')
        .set('Authorization', `Bearer ${authToken}`)
        .send(scoreData)
        .expect(201);

      expect(response.body.success).toBe(true);
      expect(response.body.data._id).toBeDefined();
      expect(response.body.data.scores.overall).toBe(85);
    });

    it('should reject duplicate score from same coach', async () => {
      // Create first score
      await createManualScore(testVideo._id, authToken);

      // Attempt duplicate
      const scoreData = {
        videoUploadsId: testVideo._id.toString(),
        gameType: 'TRIPLE_CONE_DRILL',
        granularity: 'overall',
        scores: { overall: 90 },
        scoringDuration: 60,
        status: 'submitted'
      };

      await request(app)
        .post('/api/v1/manual-scoring')
        .set('Authorization', `Bearer ${authToken}`)
        .send(scoreData)
        .expect(400);
    });

    it('should validate score range', async () => {
      const scoreData = {
        videoUploadsId: testVideo._id.toString(),
        gameType: 'TRIPLE_CONE_DRILL',
        granularity: 'overall',
        scores: { overall: 150 },
        scoringDuration: 60,
        status: 'submitted'
      };

      await request(app)
        .post('/api/v1/manual-scoring')
        .set('Authorization', `Bearer ${authToken}`)
        .send(scoreData)
        .expect(400);
    });
  });

  describe('GET /api/v1/manual-scoring/export', () => {
    beforeEach(async () => {
      // Create multiple scores
      await createMultipleScores();
    });

    it('should export as JSON', async () => {
      const response = await request(app)
        .get('/api/v1/manual-scoring/export?format=json')
        .set('Authorization', `Bearer ${authToken}`)
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(Array.isArray(response.body.data)).toBe(true);
    });

    it('should export as CSV', async () => {
      const response = await request(app)
        .get('/api/v1/manual-scoring/export?format=csv')
        .set('Authorization', `Bearer ${authToken}`)
        .expect(200);

      expect(response.headers['content-type']).toContain('text/csv');
      expect(response.text).toContain('videoId,videoUrl');
    });
  });
});
```

---

## Manual Testing

### Test Scenarios

#### Scenario 1: Happy Path - Complete Scoring Flow

**Steps**:
1. Login as PLATFORM_ADMIN user
2. Navigate to /manual-scoring
3. Verify dashboard loads with video list
4. Apply filter (drill type = TRIPLE_CONE_DRILL)
5. Search for specific player
6. Click "Score" on a video
7. Verify video player loads and plays
8. Select granularity = "Category"
9. Enter score for Dribbling: 85
10. Add notes: "Good performance"
11. Set confidence = 4, difficulty = 2
12. Click "Save Draft"
13. Verify success message
14. Navigate back to dashboard
15. Return to same video
16. Verify draft values loaded
17. Click "Submit"
18. Verify success message and redirect

**Expected Results**:
- All steps complete without errors
- Draft saves correctly
- Final submission creates record in DB
- UI responsive throughout

#### Scenario 2: Validation Errors

**Steps**:
1. Login as PLATFORM_ADMIN
2. Start scoring a video
3. Select granularity = "Overall"
4. Enter invalid score: 150
5. Click "Submit"
6. Verify error message shown
7. Correct score to 85
8. Submit successfully

**Expected Results**:
- Validation error displayed clearly
- Form prevents submission with invalid data
- Valid data submits successfully

#### Scenario 3: Access Control

**Steps**:
1. Login as regular coach (not PLATFORM_ADMIN)
2. Attempt to navigate to /manual-scoring
3. Verify access denied or redirect
4. Verify no navigation link visible
5. Logout
6. Login as PLATFORM_ADMIN
7. Verify /manual-scoring accessible
8. Verify navigation link visible

**Expected Results**:
- Non-admins cannot access manual scoring
- Admins have full access

#### Scenario 4: Comparison View

**Steps**:
1. Score a video that has AI score
2. Click "Compare with AI"
3. Verify comparison dialog opens
4. Verify AI score displayed
5. Verify manual score displayed
6. Verify difference calculated
7. Close dialog

**Expected Results**:
- Comparison loads without delay
- Scores displayed side-by-side
- Differences highlighted appropriately

#### Scenario 5: Export Functionality

**Steps**:
1. Navigate to dashboard
2. Score 5-10 videos
3. Click "Export CSV"
4. Verify CSV file downloads
5. Open CSV and verify structure
6. Click "Export JSON"
7. Verify JSON file downloads
8. Verify JSON structure

**Expected Results**:
- Files download immediately
- Data formatted correctly
- All fields present

#### Scenario 6: Quality Metrics

**Steps**:
1. Have 2-3 coaches score same video
2. Navigate to Quality Metrics tab
3. Verify inter-rater reliability shown
4. Verify coach statistics displayed
5. Check for videos with multiple scores

**Expected Results**:
- Metrics calculated correctly
- UI displays data clearly
- No performance issues

### Edge Cases to Test

1. **Video with no AI score**: Comparison should handle gracefully
2. **Very long notes**: Text field should handle 1000+ characters
3. **Rapid navigation**: Dashboard → Scoring → Back → Scoring
4. **Network failure**: Handle API errors gracefully
5. **Large dataset**: Dashboard with 1000+ videos loads within 5s
6. **Concurrent scoring**: Two coaches score same video simultaneously
7. **Browser refresh**: Draft scores persist (if implemented)
8. **Different granularities**: Switch between all 4 granularity types
9. **Activity scoring**: Score video with 10+ activities

---

## Performance Testing

### Load Testing

**Tool**: Apache JMeter or k6

**Test Cases**:

1. **Dashboard Load Time**:
   - Concurrent Users: 10
   - Request: GET /api/v1/manual-scoring/videos?limit=50
   - Target: <3s response time
   - Success Criteria: 95% requests under target

2. **Score Creation**:
   - Concurrent Users: 5
   - Request: POST /api/v1/manual-scoring
   - Target: <1s response time
   - Success Criteria: 100% success rate

3. **Export Performance**:
   - Dataset Size: 1000 records
   - Request: GET /api/v1/manual-scoring/export?format=csv
   - Target: <10s response time
   - Success Criteria: File downloads successfully

4. **Video Player**:
   - Video Size: 50MB
   - Target: Starts playing within 2s
   - Success Criteria: Smooth playback, no buffering

### Stress Testing

**Scenarios**:

1. **Database Stress**:
   - Create 10,000 manual scores
   - Query dashboard (should remain <3s)
   - Run aggregations for quality metrics

2. **Concurrent Scoring**:
   - 20 coaches scoring simultaneously
   - Monitor DB connection pool
   - Verify no deadlocks or timeouts

---

## Acceptance Criteria

### Functional Requirements

- [ ] All API endpoints return correct responses
- [ ] UI renders correctly on desktop and tablet
- [ ] Video player loads and plays smoothly
- [ ] Scoring form validates inputs correctly
- [ ] Draft saves and loads correctly
- [ ] Submitted scores saved to database
- [ ] Comparison view displays correctly
- [ ] Export generates valid CSV and JSON
- [ ] Quality metrics calculate correctly
- [ ] Access control enforces PLATFORM_ADMIN only

### Non-Functional Requirements

- [ ] Dashboard loads <3s with 50 videos
- [ ] API response time <1s for CRUD operations
- [ ] Export of 1000 records <10s
- [ ] Video player starts <2s
- [ ] No UI lag during form input
- [ ] Unit test coverage >70%
- [ ] All integration tests passing
- [ ] No console errors in browser
- [ ] No server errors in logs

---

## Bug Tracking

### Bug Report Template

```
Title: [Component] Brief description

Environment:
- Browser: Chrome 120
- OS: macOS
- Server: Staging

Steps to Reproduce:
1. Navigate to /manual-scoring
2. Click on video ID: 12345
3. Submit score

Expected Result:
Score should be saved successfully

Actual Result:
Error: "Validation failed"

Screenshots:
[Attach if applicable]

Severity: High / Medium / Low
Priority: P0 / P1 / P2 / P3
```

### Severity Levels

- **Critical (P0)**: System unusable, data loss
- **High (P1)**: Major functionality broken
- **Medium (P2)**: Minor functionality broken
- **Low (P3)**: Cosmetic issues, nice-to-have

---

**Document Version**: 1.0
**Last Updated**: 2024-12-02
