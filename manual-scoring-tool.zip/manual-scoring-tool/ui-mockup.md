# UI Mockup - Manual Scoring Tool

## Metric Granularity Form Layout

### Option A: Side-by-Side Layout (Recommended)

```
┌─────────────────────────────────────────────────────────┐
│ Scoring Configuration                                    │
├─────────────────────────────────────────────────────────┤
│                                                          │
│ Granularity: [Metric Level ▼]                          │
│                                                          │
│ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ │
│                                                          │
│ DRIBBLING                                               │
│                                                          │
│ Speed to Complete                                       │
│ ┌─────────┐           ┌─────────┐                     │
│ │  12.5   │ seconds   │   85    │ / 100               │
│ └─────────┘           └─────────┘                     │
│   Value                 Score                          │
│                                                          │
│ No. of Touches                                          │
│ ┌─────────┐           ┌─────────┐                     │
│ │   15    │ touches   │   92    │ / 100               │
│ └─────────┘           └─────────┘                     │
│   Value                 Score                          │
│                                                          │
│ Ball Distance from Foot                                 │
│ ┌─────────┐           ┌─────────┐                     │
│ │  0.35   │ meters    │   88    │ / 100               │
│ └─────────┘           └─────────┘                     │
│   Value                 Score                          │
│                                                          │
│ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ │
│                                                          │
│ PASSING                                                 │
│                                                          │
│ Angle of Ball Return                                    │
│ ┌─────────┐           ┌─────────┐                     │
│ │   45    │ degrees   │   90    │ / 100               │
│ └─────────┘           └─────────┘                     │
│   Value                 Score                          │
│                                                          │
│ Passing Duration                                        │
│ ┌─────────┐           ┌─────────┐                     │
│ │  2.3    │ seconds   │   87    │ / 100               │
│ └─────────┘           └─────────┘                     │
│   Value                 Score                          │
│                                                          │
└─────────────────────────────────────────────────────────┘
```

### Option B: Stacked Layout

```
┌─────────────────────────────────────────────────────────┐
│ Speed to Complete                                       │
│                                                          │
│ Value (seconds)                                         │
│ ┌───────────────────────────────────────────────────┐  │
│ │ 12.5                                              │  │
│ └───────────────────────────────────────────────────┘  │
│                                                          │
│ Score (0-100)                                           │
│ ┌───────────────────────────────────────────────────┐  │
│ │ 85                                                │  │
│ └───────────────────────────────────────────────────┘  │
│                                                          │
└─────────────────────────────────────────────────────────┘
```

### Option C: Compact Inline

```
┌─────────────────────────────────────────────────────────┐
│ Speed to Complete:  [12.5] sec  →  [85]/100            │
│ No. of Touches:     [ 15 ] touches  →  [92]/100        │
│ Ball Distance:      [0.35] m  →  [88]/100              │
└─────────────────────────────────────────────────────────┘
```

## Material-UI Implementation (Recommended: Option A)

```jsx
<Box sx={{ mb: 3 }}>
  <Typography variant="h6" gutterBottom sx={{ textTransform: 'uppercase', color: 'primary.main' }}>
    Dribbling
  </Typography>
  <Divider sx={{ mb: 2 }} />

  {/* Speed to Complete */}
  <Box sx={{ mb: 3 }}>
    <Typography variant="body2" color="text.secondary" gutterBottom>
      Speed to Complete
    </Typography>
    <Grid container spacing={2} alignItems="center">
      <Grid item xs={5}>
        <TextField
          fullWidth
          size="small"
          type="number"
          label="Value"
          placeholder="12.5"
          InputProps={{
            endAdornment: <InputAdornment position="end">seconds</InputAdornment>,
          }}
          value={scores.metrics?.Dribbling?.['Speed to Complete']?.value || ''}
          onChange={(e) => handleMetricChange('Dribbling', 'Speed to Complete', 'value', e.target.value)}
        />
      </Grid>
      <Grid item xs={1} sx={{ textAlign: 'center' }}>
        <ArrowForward color="action" />
      </Grid>
      <Grid item xs={6}>
        <TextField
          fullWidth
          size="small"
          type="number"
          label="Score"
          placeholder="85"
          required
          inputProps={{ min: 0, max: 100 }}
          InputProps={{
            endAdornment: <InputAdornment position="end">/ 100</InputAdornment>,
          }}
          value={scores.metrics?.Dribbling?.['Speed to Complete']?.score || ''}
          onChange={(e) => handleMetricChange('Dribbling', 'Speed to Complete', 'score', e.target.value)}
        />
      </Grid>
    </Grid>
  </Box>

  {/* Additional metrics... */}
</Box>
```

## Complete Scoring Interface Layout

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│ ← Back to Dashboard                Manual Scoring                  [Compare with AI] │
│                                                                                       │
│ PASSING_RECEIVING_TURNING - John Doe                                                │
├──────────────────────────────────────┬────────────────────────────────────────────┤
│                                      │                                            │
│                                      │  Scoring Configuration                     │
│                                      │  ────────────────────────────────────────  │
│                                      │                                            │
│  ┌────────────────────────────────┐ │  Granularity: [Metric Level ▼]           │
│  │                                │ │                                            │
│  │      VIDEO PLAYER              │ │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│  │                                │ │                                            │
│  │       [▶ Play]                 │ │  DRIBBLING                                │
│  │                                │ │                                            │
│  │   ●────────────────────○       │ │  Speed to Complete                        │
│  │   0:15 / 2:30                  │ │  [12.5] sec  →  [85]/100                 │
│  │                                │ │                                            │
│  │   [1x▼] [⚙] [⛶]               │ │  No. of Touches                           │
│  │                                │ │  [15] touches  →  [92]/100                │
│  └────────────────────────────────┘ │                                            │
│                                      │  Ball Distance from Foot                  │
│                                      │  [0.35] m  →  [88]/100                    │
│                                      │                                            │
│                                      │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│                                      │                                            │
│                                      │  PASSING                                  │
│                                      │                                            │
│                                      │  Angle of Ball Return                     │
│                                      │  [45] deg  →  [90]/100                    │
│                                      │                                            │
│                                      │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│                                      │                                            │
│                                      │  Notes:                                   │
│                                      │  ┌──────────────────────────────────────┐│
│                                      │  │ Excellent speed. Good ball control.  ││
│                                      │  │                                      ││
│                                      │  └──────────────────────────────────────┘│
│                                      │                                            │
│                                      │  Confidence: ●●●●○ (4/5)                 │
│                                      │  Difficulty: ●●○○○ (2/5)                 │
│                                      │                                            │
│                                      │  [Save Draft]  [Submit Score]             │
│                                      │                                            │
└──────────────────────────────────────┴────────────────────────────────────────────┘
```

## Mobile/Tablet Layout (Responsive)

```
┌─────────────────────────────────┐
│ ← Manual Scoring                │
├─────────────────────────────────┤
│ TRIPLE_CONE_DRILL               │
│ John Doe                        │
├─────────────────────────────────┤
│                                 │
│  ┌───────────────────────────┐ │
│  │     VIDEO PLAYER          │ │
│  │       [▶]                 │ │
│  └───────────────────────────┘ │
│                                 │
├─────────────────────────────────┤
│ [⚙ Configuration ▼]            │
│                                 │
│ Granularity: [Metric▼]         │
│                                 │
│ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ │
│                                 │
│ DRIBBLING                       │
│                                 │
│ Speed to Complete               │
│ Value: [12.5] sec              │
│ Score: [85]/100                │
│                                 │
│ No. of Touches                  │
│ Value: [15] touches            │
│ Score: [92]/100                │
│                                 │
│ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ │
│                                 │
│ [Save Draft] [Submit]           │
│                                 │
└─────────────────────────────────┘
```

## Comparison View Layout

```
┌───────────────────────────────────────────────────────────────────────────┐
│ AI vs Manual Score Comparison                                     [Close] │
├───────────────────────────────────────────────────────────────────────────┤
│                                                                           │
│ ┌──────────────────────────┬──────────────────────────┐                 │
│ │    AI Score              │    Manual Score          │                 │
│ │                          │                          │                 │
│ │    Total: 83             │    Total: 87             │                 │
│ │    ✓ Processed           │    ✓ Submitted           │                 │
│ │                          │    Coach: John Smith     │                 │
│ └──────────────────────────┴──────────────────────────┘                 │
│                                                                           │
│ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ │
│                                                                           │
│ Detailed Comparison                                                      │
│                                                                           │
│ ┌─────────────────────────────────────────────────────────────────────┐ │
│ │ Category/Metric         │ AI Value │ AI Score │ Manual Value │ Score │ │
│ ├─────────────────────────────────────────────────────────────────────┤ │
│ │ DRIBBLING                                                           │ │
│ │ Speed to Complete       │  12.3s   │    83    │    12.5s     │  85  │ │
│ │ No. of Touches          │    14    │    90    │      15      │  92  │ │
│ │ Ball Distance from Foot │  0.33m   │    86    │    0.35m     │  88  │ │
│ │                                                                     │ │
│ │ PASSING                                                             │ │
│ │ Angle of Ball Return    │   43°    │    88    │     45°      │  90  │ │
│ └─────────────────────────────────────────────────────────────────────┘ │
│                                                                           │
│ Color Legend:                                                            │
│ ● Green: Difference <5 points   ● Yellow: 5-10 points   ● Red: >10 pts  │
│                                                                           │
└───────────────────────────────────────────────────────────────────────────┘
```

## Value Field Helpers

### Input Field with Unit Helper Text

```jsx
<TextField
  label="Speed to Complete"
  type="number"
  helperText="Enter time in seconds (e.g., 12.5)"
  InputProps={{
    endAdornment: <InputAdornment position="end">seconds</InputAdornment>,
  }}
/>
```

### Common Metric Units Display

| Metric | Display Unit | Input Format |
|--------|--------------|--------------|
| Speed to Complete | seconds | 12.5 |
| No. of Touches | touches | 15 |
| Ball Distance from Foot | meters (m) | 0.35 |
| Angle of Ball Return | degrees (°) | 45 |
| Passing Duration | seconds | 2.3 |
| Ball Speed Return | m/s | 8.5 |

---

**Document Version**: 1.0
**Last Updated**: 2024-12-02
**Purpose**: Visual reference for developers implementing the UI
