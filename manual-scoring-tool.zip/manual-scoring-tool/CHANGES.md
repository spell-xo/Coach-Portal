# Changes Log - Manual Scoring Tool

## Change #1: Value + Score for Metric Granularity (2024-12-02)

### Requirement
User needs ability to record both the **raw measured value** AND the **subjective score** for each metric when using metric-level granularity.

**Example Use Case**:
- Metric: "Speed to Complete"
- Value: 12.5 (seconds) - the actual measured time
- Score: 85 (out of 100) - coach's assessment of how good that time is

### Changes Made

#### 1. Database Schema Updated

**File**: `database-schema.md`

**Before**:
```typescript
metrics?: {
  [categoryName: string]: {
    [metricName: string]: number;  // Just a score
  };
}
```

**After**:
```typescript
metrics?: {
  [categoryName: string]: {
    [metricName: string]: {
      value?: number | string;  // Raw measured value
      score: number;            // Subjective score 0-100
    };
  };
}
```

**Example Data**:
```json
{
  "metrics": {
    "Dribbling": {
      "Speed to Complete": {
        "value": 12.5,    // 12.5 seconds
        "score": 85       // 85/100 score
      },
      "No. of Touches": {
        "value": 15,      // 15 touches
        "score": 92       // 92/100 score
      },
      "Ball Distance from Foot": {
        "value": 0.35,    // 0.35 meters
        "score": 88       // 88/100 score
      }
    }
  }
}
```

#### 2. API Specification Updated

**File**: `api-specification.md`

Added note explaining the metric structure:
- `value`: The raw measured value (e.g., 12.5 seconds, 15 touches, 0.35 meters)
- `score`: The subjective score (0-100) based on that value

Updated all metric examples to show both fields.

#### 3. Implementation Plan Updated

**File**: `implementation-plan.md`

Updated ScoringForm component specification to include **TWO input fields per metric**:
- Value field (raw measurement)
- Score field (0-100)

### Impact on Implementation

#### Backend Changes Needed
- **DAO Layer**: No changes needed - schema flexible enough
- **Service Layer**: Validation needs to check for `score` field (required) and optionally `value` field
- **Export**: CSV export should include both value and score columns

#### Frontend Changes Needed
- **ScoringForm Component**:
  - Render TWO inputs per metric (side-by-side or stacked)
  - Value input: Number or text input (flexible type)
  - Score input: Number input (0-100 validation)
  - Example layout:
    ```
    Speed to Complete
    [ 12.5 ] seconds    [ 85 ] /100
    (value)  (unit)     (score)
    ```

- **ComparisonView Component**:
  - Show both value and score when comparing
  - Display format: "Value: 12.5s | Score: 85 vs AI: 83"

### Metric Units Reference

For UI implementation, here are common metric units:

| Metric Name | Unit | Value Type | Example |
|-------------|------|------------|---------|
| Speed to Complete | seconds | number | 12.5 |
| No. of Touches | count | number | 15 |
| Ball Distance from Foot | meters | number | 0.35 |
| Angle of Ball Return | degrees | number | 45 |
| Passing Duration | seconds | number | 2.3 |
| Ball Control Distance | meters | number | 0.42 |
| Ball Speed Return | m/s | number | 8.5 |
| First Touch Distance | meters | number | 0.28 |

### Validation Rules

#### Value Field
- Optional (can be left blank if coach doesn't measure)
- Type: number or string (flexible)
- No min/max validation (depends on metric)

#### Score Field
- Required
- Type: number
- Range: 0-100
- Validation: Must be present and in range

### Example API Request

```json
{
  "videoUploadsId": "60d5ec49f1b2c8b1f8c4e125",
  "gameType": "TRIPLE_CONE_DRILL",
  "granularity": "metric",
  "scores": {
    "metrics": {
      "Dribbling": {
        "Speed to Complete": {
          "value": 12.5,
          "score": 85
        },
        "No. of Touches": {
          "value": 15,
          "score": 92
        },
        "Ball Distance from Foot": {
          "value": 0.35,
          "score": 88
        }
      }
    }
  },
  "notes": "Excellent time of 12.5 seconds with good ball control",
  "scoringDuration": 240,
  "status": "submitted"
}
```

### CSV Export Format

For metric granularity, the CSV should include both value and score:

```csv
videoId,gameType,category,metric,value,score,unit,coachName,timestamp
60d5ec49,TRIPLE_CONE_DRILL,Dribbling,Speed to Complete,12.5,85,seconds,John Smith,2024-12-02T10:30:00Z
60d5ec49,TRIPLE_CONE_DRILL,Dribbling,No. of Touches,15,92,count,John Smith,2024-12-02T10:30:00Z
60d5ec49,TRIPLE_CONE_DRILL,Dribbling,Ball Distance from Foot,0.35,88,meters,John Smith,2024-12-02T10:30:00Z
```

### Backward Compatibility

**Question**: What if existing implementations only send a score (number)?

**Answer**: The schema allows for this:
- `value` is optional
- `score` is required
- Backend validation should accept both formats:
  - Old format: `"Speed to Complete": 85` (just a number)
  - New format: `"Speed to Complete": { value: 12.5, score: 85 }`

**Recommendation**: Backend service should normalize old format to new format:
```javascript
// In validation/normalization layer
if (typeof metricValue === 'number') {
  // Old format: just a score
  return { score: metricValue };
} else if (typeof metricValue === 'object') {
  // New format: with value and score
  return { value: metricValue.value, score: metricValue.score };
}
```

---

## Future Changes

### Potential Enhancement #1: Metric Units
Add a `unit` field to make it explicit:
```json
{
  "Speed to Complete": {
    "value": 12.5,
    "unit": "seconds",
    "score": 85
  }
}
```

### Potential Enhancement #2: Value Validation
Add min/max ranges per metric:
```json
{
  "Speed to Complete": {
    "value": 12.5,
    "score": 85,
    "validation": {
      "min": 0,
      "max": 60,
      "unit": "seconds"
    }
  }
}
```

---

**Last Updated**: 2024-12-02
**Version**: 1.1
