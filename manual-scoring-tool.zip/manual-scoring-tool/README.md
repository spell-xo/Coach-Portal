# Manual Scoring Tool Documentation

## Overview

The Manual Scoring Tool enables expert football coaches to manually score drill videos, creating high-quality training datasets for supervised learning to improve the AI scoring model.

## Purpose

- Generate ground truth data for AI model training
- Enable comparison between human expert scores and AI-generated scores
- Track scoring quality metrics and inter-rater reliability
- Export training datasets in multiple formats (CSV, JSON)

## Key Features

- **Configurable Granularity**: Score at overall, category, metric, or activity level
- **Numeric Scoring**: 0-100 scale matching AI output format
- **Free Selection Workflow**: Browse and choose videos to score
- **AI Comparison**: Side-by-side comparison of manual vs AI scores
- **Quality Metrics**: Inter-rater reliability and consistency tracking
- **Data Export**: CSV/JSON export for ML pipelines
- **Role-Based Access**: Restricted to PLATFORM_ADMIN users

## Documentation Structure

1. **[PRD.md](./PRD.md)** - Product Requirements Document
2. **[technical-specifications.md](./technical-specifications.md)** - Technical architecture and design
3. **[database-schema.md](./database-schema.md)** - Database schema design with examples
4. **[api-specification.md](./api-specification.md)** - Complete API endpoint documentation
5. **[ui-specifications.md](./ui-specifications.md)** - Frontend component specifications
6. **[implementation-plan.md](./implementation-plan.md)** - Step-by-step implementation guide
7. **[testing-strategy.md](./testing-strategy.md)** - Testing approach and test cases
8. **[deployment-guide.md](./deployment-guide.md)** - Deployment procedures and checklist

## Quick Start

### For Product Owners
- Read [PRD.md](./PRD.md) for requirements and user stories
- Review [ui-specifications.md](./ui-specifications.md) for UX flows

### For Developers
- Start with [technical-specifications.md](./technical-specifications.md)
- Follow [implementation-plan.md](./implementation-plan.md) for build steps
- Reference [api-specification.md](./api-specification.md) for endpoints

### For QA/Testers
- Review [testing-strategy.md](./testing-strategy.md)
- Use [deployment-guide.md](./deployment-guide.md) for staging setup

## Technology Stack

- **Backend**: Node.js, Express, MongoDB (aim-coach-portal-api)
- **Frontend**: React, Material-UI, Redux (aim-coach-portal-ui)
- **Database**: MongoDB with Mongoose ODM
- **Shared**: aim-common-plugin for schemas and types

## Integration Points

- Integrates with existing Coach Portal authentication system
- Uses existing video player components (EnhancedVideoPlayer)
- Leverages existing drill upload and management infrastructure
- Connects to VideoUploads and DrillScores collections

## User Roles

- **PLATFORM_ADMIN**: Full access to scoring tool, dashboard, and exports
- **Other Roles**: No access (feature is admin-only)

## Related Systems

- **Video Upload System**: Source of videos to be scored
- **AI Scoring System**: Comparison baseline for ground truth validation
- **Drill Management**: Video metadata and player information
- **Quality Metrics**: Inter-rater reliability tracking

## Support

For questions or issues:
- Technical: Review technical-specifications.md
- API: Check api-specification.md
- Implementation: Follow implementation-plan.md

---

**Last Updated**: 2024-12-02
**Version**: 1.0.0
**Status**: Planning Complete
